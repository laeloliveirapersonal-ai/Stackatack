(()=>{
const W=12,H=9,C=52,FX=16,FY=492,CT=[0,0,1,2,0,1];
const $=id=>document.getElementById(id),cv=$('c'),cx=cv.getContext('2d');
const IM={};let ld=0,nI=0;for(const k in AS){nI++;const i=new Image();i.onload=()=>ld++;i.src=AS[k];IM[k]=i}
let st='title',boxes=[],P,score=0,level=1,lives=3,rows=0,spawnT=0,nextCol=0,gT=0,t=0,best=0,mute=0,jumpQ=0,iv=2.6,crane={x:6,ct:2};
const keys={};
try{best=+localStorage.getItem('sa_best')||0;mute=+localStorage.getItem('sa_mute')||0}catch(e){}
let ac;function beep(f,d=.08,ty='square'){if(mute)return;try{ac=ac||new(window.AudioContext||window.webkitAudioContext)();const o=ac.createOscillator(),g=ac.createGain();o.type=ty;o.frequency.value=f;g.gain.value=.05;o.connect(g);g.connect(ac.destination);o.start();o.stop(ac.currentTime+d)}catch(e){}}
const boxAt=(x,y)=>boxes.find(b=>b.x==x&&b.y==y);
const rnd=n=>Math.floor(Math.random()*n);
const ap=(a,b,m)=>a<b?Math.min(a+m,b):Math.max(a-m,b);
const sup=()=>P.y==0||!!boxAt(P.x,P.y-1);
function spawnP(){P.face=P.face||1;P.dead=0;P.hit=0;P.x=7;P.y=0;while(boxAt(P.x,P.y))P.y++;P.rx=P.x;P.ry=P.y;P.busy=0;P.air=0;P.anim='idle'}
P={};spawnP();
function hud(){$('sc').textContent=score;$('lv').textContent=level;$('lf').textContent='♥'.repeat(Math.max(0,lives))||'–';$('bs').textContent=best;$('bm').style.opacity=mute?.4:1;if(typeof puzzleChrome==='function')puzzleChrome()}
function show(h,p,b){$('ov').innerHTML='<h2>'+h+'</h2><p>'+p+'</p><button id="ob">'+b+'</button>';$('ov').style.display='flex';$('ob').onclick=act}
function act(){if(st=='pause'){st='play';$('ov').style.display='none'}else start()}
function start(){boxes=[[2,0],[4,0],[4,1],[6,0]].map(([x,y])=>({x,y,rx:x,ry:y,tx:1+rnd(6),s:1}));
score=0;level=1;lives=3;rows=0;spawnT=-.6;gT=0;nextCol=rnd(W);crane.x=6;crane.ct=1+rnd(6);P.x=7;spawnP();st='play';$('ov').style.display='none';hud();beep(660)}
function pause(){if(st!='play')return;st='pause';show('PAUSADO','Toque para continuar.','CONTINUAR')}
function over(){st='over';P.dead=t;if(score>best){best=score;try{localStorage.setItem('sa_best',best)}catch(e){}}hud();beep(120,.5,'sawtooth');show('FIM DE JOGO','Pontos: '+score+' · Linhas: '+rows+'<br>Recorde: '+best,'JOGAR DE NOVO')}
function crush(){beep(90,.3,'sawtooth');lives--;hud();cv.classList.remove('hit');void cv.offsetWidth;cv.classList.add('hit');
if(lives<=0)return over();boxes=boxes.filter(b=>b.y<2);spawnP();P.hit=.8;spawnT=-1;gT=0}
function gravity(){boxes.sort((a,b)=>a.y-b.y);
for(const b of boxes){if(b.y==0||boxAt(b.x,b.y-1))continue;const ny=b.y-1;
if((gameMode==='modern'||gameMode==='survival')&&b.x===P.x&&b.y===P.y+1)continue;
if(P.x==b.x&&(ny==P.y||ny==P.y+1)){if((gameMode==='modern'||gameMode==='survival')&&shieldReady){if(gameMode==='modern'){shieldReady=false;delete activeEffects.shield}b.y=P.y+1;b.s=1;beep(700,.12,'triangle');renderPowerButtons();updateCampaignHud();continue}return crush()}b.y=ny}
boxes.sort((a,b)=>a.y-b.y);
for(const b of boxes){const d=b.y>0&&boxAt(b.x,b.y-1);b.s=b.y==0||(d&&d.s)?1:0}
if(boxes.some(b=>b.s&&b.y>=H))return over();
const full=[];for(let y=0;y<H;y++)if(boxes.filter(b=>b.y==y&&b.s).length==W)full.push(y);
if(full.length){if(gameMode==='modern'){for(const y of full){lineBursts.push({y,age:0,particles:Array.from({length:48},()=>({x:Math.random()*W,y:y+(Math.random()-.5)*.75,vx:(Math.random()-.5)*9,vy:(Math.random()-.5)*9,life:.35+Math.random()*.4,color:['#ffb347','#ff6b35','#ffe36e','#ffffff','#43d9a3'][rnd(5)]}))})}}boxes=boxes.filter(b=>!full.includes(b.y));const n=full.length;score+=100*level*n*n;rows+=n;
const nl=1+Math.floor(rows/4);if(nl>level)beep(880,.2);level=nl;beep(520,.15);setTimeout(()=>beep(780,.2),120);hud()}}
function tryMove(d){P.face=d;const nx=P.x+d;if(nx<0||nx>=W)return false;const s=sup();
if(!boxAt(nx,P.y)&&!boxAt(nx,P.y+1)&&(s||boxAt(nx,P.y-1))){P.x=nx;P.busy=.14;P.anim=d<0?'wl':'wr';return true}
const bx=boxAt(nx,P.y),n2=nx+d;
if(bx&&n2>=0&&n2<W&&!boxAt(n2,P.y)&&
   (P.air>0||P.y>0||bx.s)&&
   (!boxAt(nx,P.y+1)||P.y>0)){
 bx.x=n2;P.x=nx;P.busy=.18;P.anim=d<0?'pl':'pr';beep(220,.07);return true
}
return false}
function step(dt){
iv=Math.max(.9,2.6-.2*(level-1));if(gameMode==='modern'){if(campaignStage===2)iv=Math.min(iv,2.0);if(campaignStage===3)iv=Math.min(iv,1.8);if(campaignStage===4)iv=Math.min(iv,1.45);if(campaignStage===5)iv=Math.min(iv,1.2)}const G=Math.max(.1,.2-.012*(level-1));
spawnT+=dt;if(gameMode==='modern'&&campaignStage===4&&spawnT<iv)nextCol=Math.max(0,Math.min(W-1,Math.round(P.x)));crane.x=ap(crane.x,nextCol,dt*9);
if(spawnT>=iv){if(Math.abs(crane.x-nextCol)<.05){boxes.push({x:nextCol,y:H,rx:nextCol,ry:8,tx:crane.ct,s:0});nextCol=(gameMode==='modern'&&campaignStage===4)?Math.max(0,Math.min(W-1,P.x)):rnd(W);crane.ct=1+rnd(6);spawnT=0;beep(300,.05)}else spawnT=iv}
gT+=dt;while(gT>=G&&st=='play'){gT-=G;gravity()}
if(st!='play')return;
jumpQ=Math.max(0,jumpQ-dt);P.hit=Math.max(0,P.hit-dt);
if(P.busy>0)P.busy-=dt;
if(P.busy<=0){const s=sup(),dir=(keys.r?1:0)-(keys.l?1:0);
 if(s)P.air=0;
 if(jumpQ>0&&s&&P.y+2<=H-1&&!boxAt(P.x,P.y+2)){jumpQ=0;if(dir)P.face=dir;const nx=P.x+dir;
 if(dir&&nx>=0&&nx<W&&boxAt(nx,P.y)&&!boxAt(nx,P.y+1)&&!boxAt(nx,P.y+2)){P.x=nx;P.y++;P.busy=.22;P.air=0;P.anim='jump';beep(440,.07)}
 else{P.y++;P.busy=.16;P.air=0;P.anim='jump';if((gameMode==='modern'||gameMode==='survival')&&activeEffects.jump>0)doubleJumpReady=true;beep(440,.07)}}
 else if(jumpQ>0&&(gameMode==='modern'||gameMode==='survival')&&activeEffects.jump>0&&!s&&doubleJumpReady&&P.y+1<H&&!boxAt(P.x,P.y+1)){jumpQ=0;doubleJumpReady=false;P.y++;P.busy=.16;P.air=0;P.anim='jump';beep(620,.08,'triangle')}
 else if(dir&&tryMove(dir)){}
 else if(!s){P.air+=dt;P.anim='jump';if(P.air>=.12){P.y--;P.busy=.07;P.air=0}}
 else P.anim='idle'}
for(const b of boxes){b.ry=ap(b.ry,b.y,dt*12);b.rx=ap(b.rx,b.x,dt*8)}
P.rx=ap(P.rx,P.x,dt*10);P.ry=ap(P.ry,P.y,dt*10)}
function frame(){const a=P.anim;
if(P.hit>0)return IM['h'+Math.min(3,Math.floor((.8-P.hit)/.8*4))];
if(a=='jump'){if(P.ry<P.y-.15)return IM[P.ry<P.y-.6?'j0':'j1'];return IM['f'+Math.floor(t*10)%4]}
if(a=='wl'||a=='wr')return IM['r'+Math.floor(t*12)%9];
if(a=='pl'||a=='pr')return IM.s0;
return IM['i'+Math.floor(t*3)%4]}
function draw(){if(ld<nI)return;cx.drawImage(IM.bg,0,0);
for(const b of boxes)cx.drawImage(IM['c'+CT[b.tx-1]],FX+b.rx*C,FY-(b.ry+1)*C,C,C);
if(gameMode==='modern'){for(const burst of lineBursts){const fade=Math.max(0,1-burst.age/.75);for(const q of burst.particles){if(q.life<=0)continue;cx.globalAlpha=fade*Math.min(1,q.life*4);cx.fillStyle=q.color;const sz=Math.max(2,5*fade);cx.fillRect(FX+q.x*C,FY-(q.y+1)*C,sz,sz)}cx.globalAlpha=1}}
const px=FX+P.rx*C+C/2,py=FY-P.ry*C;
if(P.dead){const el=t-P.dead;if(el<.45){cx.drawImage(IM.g0,px-56,py-112)}else{const k=Math.min(1,(el-.45)/1.5);cx.globalAlpha=1-k*.4;cx.drawImage(IM['g'+(1+Math.min(2,Math.floor((el-.45)*4)))],px-56,py-112-k*60);cx.globalAlpha=1}}
else{cx.save();cx.translate(px,py);if(P.face<0)cx.scale(-1,1);cx.drawImage(frame(),-56,-112+((P.anim=='pl'||P.anim=='pr')?Math.round(Math.sin(t*16)*1.5):0));cx.restore()}
cx.drawImage(IM.ceil,0,116);
if(st=='play'&&spawnT>iv-1.2&&Math.floor(t*8)%2){const c=FX+nextCol*C+C/2;cx.fillStyle='#ffb347';cx.beginPath();cx.moveTo(c-12,136);cx.lineTo(c+12,136);cx.lineTo(c,156);cx.fill()}
const gx=FX+crane.x*C;cx.strokeStyle='#111';cx.lineWidth=2;cx.beginPath();cx.moveTo(gx+10,20);cx.lineTo(gx+10,30);cx.moveTo(gx+C-10,20);cx.lineTo(gx+C-10,30);cx.stroke();
cx.drawImage(IM['c'+CT[crane.ct-1]],gx,24,C,C);
cx.fillStyle='#e8741c';cx.fillRect(gx+4,5,C-8,15);cx.fillStyle='#2a1a12';cx.fillRect(gx+4,5,C-8,3);cx.fillStyle='#ffd9a8';cx.fillRect(gx+10,12,C-20,3)}

// Campanha Moderna adicionada ao motor existente; os gráficos e a física clássica são preservados.
let survivalPowerTimers={shield:0,jump:0},survivalElapsed=0;let gameMode='classic',campaignStage=1,unlockedStage=1,coins=0,stageRows=0,stageStartedAt=0,activeEffects={},powerInventory={},preservePowersForNextStage=false,shieldReady=false,shopReturnState='play',stageCompleteMarkup='',stageCompleteStage=1,stageHits=0,stageStartY=0,maxHeightReached=0,floorsClimbed=0,stageFailed=false,stageHudClock=0,stageSurvivalTime=0,doubleJumpReady=false,lineBursts=[];
const stageInfo=[{name:'Primeiros Passos',goal:5,type:'lines',desc:'Complete 5 linhas para vencer a fase.'},{name:'Suba 6 Andares',goal:6,type:'climb',desc:'Alcance uma altura 6 andares acima do ponto inicial.'},{name:'Desafio das 10 Linhas',goal:10,type:'lines',desc:'Complete 10 linhas para vencer a fase.'},{name:'Caixas Perseguidoras',goal:120,type:'survive',time:120,desc:'Sobreviva por 120 segundos sem ser atingido. A CPU mira caixas na sua posição.'},{name:'Altura Máxima',goal:6,type:'height',desc:'Alcance o último andar da arena (altura máxima).'}];
const shopItems=[{id:'shield',name:'Escudo',price:25,desc:'Bloqueia uma única caixa nesta fase.',duration:0},{id:'jump',name:'Salto duplo',price:30,desc:'Permite dar um segundo salto no ar nesta fase.',duration:0}];
try{coins=+localStorage.getItem('sa_modern_coins')||0;campaignStage=Math.max(1,Math.min(5,+localStorage.getItem('sa_modern_stage')||1));unlockedStage=Math.max(campaignStage,Math.min(5,+localStorage.getItem('sa_modern_unlocked')||1))}catch(e){}
function saveCampaign(){try{localStorage.setItem('sa_modern_coins',coins);localStorage.setItem('sa_modern_stage',campaignStage);localStorage.setItem('sa_modern_unlocked',unlockedStage)}catch(e){}updateCampaignHud()}
function renderPowerButtons(){
 const bar=$('powerBar');if(!bar)return;
 if(gameMode!=='modern'||st!=='play'){bar.style.display='none';bar.innerHTML='';return}
 const ids=[...new Set([...Object.keys(powerInventory).filter(id=>powerInventory[id]>0),...Object.keys(activeEffects).filter(id=>activeEffects[id]>0),...(shieldReady?['shield']:[])])].filter(id=>['shield','jump'].includes(id));
 bar.style.display=ids.length?'flex':'none';
 bar.innerHTML=ids.map(id=>{const it=shopItems.find(x=>x.id===id);if(!it)return '';const active=(activeEffects[id]>0)||(id==='shield'&&shieldReady);const label=gameMode==='survival'?(active?'ATIVO · '+Math.ceil(survivalPowerTimers[id]||0)+'s':'ATIVAR · 30s'):(active?'ATIVO · ':'USAR · ')+it.name;return '<button data-power="'+id+'" class="'+(active?'power-active':'')+'" '+(active?'disabled':'')+'>'+(gameMode==='survival'?label:label+(active?'':' ×'+powerInventory[id]))+'</button>'}).join('');
 bar.querySelectorAll('[data-power]').forEach(b=>b.onclick=()=>activatePower(b.dataset.power));
}
function updateCampaignHud(){const coin=$('coinCount'),stage=$('stageHud');if(coin)coin.textContent=coins;if(stage)stage.textContent=gameMode==='modern'?campaignStage+'/5':'—';for(const id of ['campaignHud','coinHud','shopBtn','objectiveHud']){const el=$(id);if(el)el.style.display=gameMode==='modern'?'block':'none'}const shop=$('shopBtn');if(shop){shop.disabled=!(gameMode==='modern'&&st==='play');shop.style.opacity=st==='play'?'1':'.72';shop.style.pointerEvents=gameMode==='modern'?'auto':'none'}updateObjectiveHud();renderPowerButtons();puzzleChrome()}
function updateObjectiveHud(){const panel=$('objectiveHud');if(!panel)return;if(gameMode!=='modern'){panel.style.display='none';return}panel.style.display='grid';const cfg=stageInfo[campaignStage-1];if(!cfg)return;const title=$('objectiveTitle'),txt=$('objectiveText'),pt=$('objectiveProgressText'),bar=$('objectiveProgress');if(title)title.textContent='FASE '+campaignStage+' — '+cfg.name.toUpperCase();let progress=0,goal=cfg.goal,detail='';if(cfg.type==='lines'){progress=stageRows;detail='Linhas concluídas: '+Math.min(progress,goal)+' / '+goal}else if(cfg.type==='climb'){progress=Math.max(0,maxHeightReached-stageStartY);detail='Altura alcançada: '+Math.min(progress,goal)+' / '+goal+' andares'}else if(cfg.type==='survive'){progress=Math.max(0,Math.floor(stageSurvivalTime));detail='Tempo: '+Math.min(progress,goal)+' / '+goal+' s · Acertos: '+stageHits}else{progress=maxHeightReached;goal=H-3;detail='Altura máxima: '+Math.min(progress,goal)+' / '+goal+' andares'}if(txt)txt.textContent=cfg.desc;if(pt)pt.textContent=detail;if(bar)bar.style.width=(Math.min(100,goal?progress/goal*100:0))+'%'}

// Modo Puzzle: Sokoban clássico com apresentação visual da versão moderna.
let puzzleActive=false,puzzleLevel=1,puzzleMoves=0,puzzleHistory=[],puzzleMap=[],puzzlePlayer={x:1,y:1},puzzleBoxes=[],puzzleGoals=[],puzzleWalls=[],puzzleCols=9,puzzleRows=7;
const puzzleMaps=[
['#######','#.    #','#   @ #','#  #$ #','#     #','#######'],
['########','#  ##@ #','#      #','# $ #  #','##   . #','########'],
['########','# .  # #','# #    #','#   #$ #','#@#    #','########'],
['########','## #  +#','#  $ # #','#      #','#      #','########'],
['########','# .  # #','#    $ #','##   $@#','#  # # #','# .    #','########'],
['########','##     #','#  # $ #','# ##   #','#.$.   #','#@ # # #','########'],
['########','#   #  #','##   . #','#  $#  #','# $ # .#','#   @ ##','########'],
['#######','#    @#','#..   #','# $ $ #','## #  #','#######'],
['########','#   # @#','#   $ ##','#  #.#.#','# $    #','#  #   #','########'],
['########','# @#.  #','# $# . #','# $    #','# # #  #','# #  # #','########'],
['#########','#    # +#','#     . #','#    $  #','# . $$  #','#       #','#########'],
['########','# @   .#','# $  ###','# $    #','#   .$ #','#     .#','########'],
['#########','#     ###','# $@#   #','#  .    #','# $ #.$.#','# #     #','#########'],
['#########','#       #','# $   $ #','#   #.. #','# $ @ #.#','#       #','#########'],
['#########','#       #','#  $  . #','# $#.   #','# $     #','# #    +#','#########'],
['########','# @.. .#','#####$ #','#      #','## $ $ #','#     ##','########'],
['########','#  #@. #','# . $$ #','#    $ #','#. . $##','#      #','########'],
['########','#    ..#','#  $.# #','# $$   #','#  # $.#','#@     #','########'],
['########','#     .#','#.    .#','##  $  #','#@$$#$ #','#   . ##','########'],
['########','#     ##','#$$ #$ #','#.# .  #','# #  $@#','#..    #','########']
];
const puzzlePar=[11, 14, 21, 25, 17, 22, 27, 29, 33, 37, 23, 25, 31, 34, 37, 41, 29, 31, 31, 35];
// ---- Puzzle v2: tabuleiro desenhado no canvas com os mesmos sprites da campanha ----
const PZ_KEY='sa_puzzle_v2',PZ_DONE=20;
const PZD={
  "wd0":"../img/puzzle/wd0.png",
  "wd1":"../img/puzzle/wd1.png",
  "wd2":"../img/puzzle/wd2.png",
  "wd3":"../img/puzzle/wd3.png",
  "wu0":"../img/puzzle/wu0.png",
  "wu1":"../img/puzzle/wu1.png",
  "wu2":"../img/puzzle/wu2.png",
  "wu3":"../img/puzzle/wu3.png",
  "wl0":"../img/puzzle/wl0.png",
  "wl1":"../img/puzzle/wl1.png",
  "wl2":"../img/puzzle/wl2.png",
  "wl3":"../img/puzzle/wl3.png",
  "wr0":"../img/puzzle/wr0.png",
  "wr1":"../img/puzzle/wr1.png",
  "wr2":"../img/puzzle/wr2.png",
  "wr3":"../img/puzzle/wr3.png",
  "pd0":"../img/puzzle/pd0.png",
  "pd1":"../img/puzzle/pd1.png",
  "pd2":"../img/puzzle/pd2.png",
  "pd3":"../img/puzzle/pd3.png",
  "pu0":"../img/puzzle/pu0.png",
  "pu1":"../img/puzzle/pu1.png",
  "pu2":"../img/puzzle/pu2.png",
  "pu3":"../img/puzzle/pu3.png",
  "pl0":"../img/puzzle/pl0.png",
  "pl1":"../img/puzzle/pl1.png",
  "pl2":"../img/puzzle/pl2.png",
  "pl3":"../img/puzzle/pl3.png",
  "pr0":"../img/puzzle/pr0.png",
  "pr1":"../img/puzzle/pr1.png",
  "pr2":"../img/puzzle/pr2.png",
  "pr3":"../img/puzzle/pr3.png",
  "idle0":"../img/puzzle/idle0.png",
  "idle1":"../img/puzzle/idle1.png",
  "idle2":"../img/puzzle/idle2.png",
  "idle3":"../img/puzzle/idle3.png",
  "win0":"../img/puzzle/win0.png",
  "win1":"../img/puzzle/win1.png",
  "hurt0":"../img/puzzle/hurt0.png",
  "hurt1":"../img/puzzle/hurt1.png",
  "think0":"../img/puzzle/think0.png",
  "think1":"../img/puzzle/think1.png",
  "box0":"../img/puzzle/box0.png",
  "box1":"../img/puzzle/box1.png",
  "box2":"../img/puzzle/box2.png",
  "box3":"../img/puzzle/box3.png",
  "boxt0":"../img/puzzle/boxt0.png",
  "boxt1":"../img/puzzle/boxt1.png",
  "boxt2":"../img/puzzle/boxt2.png",
  "boxt3":"../img/puzzle/boxt3.png",
  "tgt0":"../img/puzzle/tgt0.png",
  "tgt1":"../img/puzzle/tgt1.png",
  "tgt2":"../img/puzzle/tgt2.png",
  "tgt3":"../img/puzzle/tgt3.png"
},PZSC=.75,PZS={};let pzReady=0,pzDir='d';const pzN=Object.keys(PZD).length;
for(const k in PZD){const i=new Image();i.onload=()=>pzReady++;i.src=PZD[k];PZS[k]=i}
function pzHide(b){if(!puzzleLast.push||st==='puzzlewon'||pzDir==='d')return false;const V={d:[0,1],u:[0,-1],l:[-1,0],r:[1,0]}[pzDir];if(b.x!==puzzlePlayer.x+V[0]||b.y!==puzzlePlayer.y+V[1])return false;return Math.abs(pzPR.x-puzzlePlayer.x)>.04||Math.abs(pzPR.y-puzzlePlayer.y)>.04}
function pzSpr(g,im,ax,x,y,u){const w=im.width/PZSC*u,h=im.height/PZSC*u;g.drawImage(im,x-w*ax,y-h,w,h)}
let puzzleHint=null,puzzleHintUsed=false,puzzleBest={},puzzleFace=1,puzzleLast={push:0,t:-9},puzzleBump={dx:0,dy:0,t:-9},pzPR={x:1,y:1},pzDrawT=0,pzParts=[];
try{puzzleBest=JSON.parse(localStorage.getItem(PZ_KEY)||'{}')||{}}catch(e){puzzleBest={}}
function buzz(p){try{if(navigator.vibrate)navigator.vibrate(p)}catch(e){}}
function puzzleSolved(){return puzzleBoxes.length>0&&puzzleBoxes.every(b=>puzzleGoals.some(g=>g.x===b.x&&g.y===b.y))}
function puzzlePlaced(){return puzzleBoxes.filter(b=>puzzleGoals.some(g=>g.x===b.x&&g.y===b.y)).length}
function puzzleChrome(){
 const on=gameMode==='puzzle',tiles=document.querySelectorAll('.hud > div:nth-child(-n+4)');
 const lab=on?['FASE','MOVIMENTOS','CAIXAS','MELHOR']:['PONTOS','NÍVEL','VIDAS','RECORDE'];
 tiles.forEach((d,i)=>{if(d.firstChild)d.firstChild.nodeValue=lab[i]});
 document.body.classList.toggle('puzzle-on',on);document.body.classList.toggle('pz-compact',on&&puzzleLevel>3);const pad=document.querySelector('.pad'),pp=$('ppad');
 if(pad)pad.style.display=on?'none':'';
 if(pp)pp.style.display=on?'':'none';
 if(on){
  const a=puzzleActive,oh=$('objectiveHud');
  if(a&&oh){oh.style.display='grid';$('objectiveTitle').textContent='OBJETIVO';$('objectiveText').textContent=puzzleBoxes.length>1?'Leve as '+puzzleBoxes.length+' caixas até os alvos.':'Leve a caixa até o destino.';$('objectiveProgressText').textContent='';$('objectiveProgress').style.width=Math.round(100*puzzlePlaced()/Math.max(1,puzzleBoxes.length))+'%'}
  $('sc').textContent=a?puzzleLevel+'/'+PZ_DONE:'–';
  $('lv').textContent=a?puzzleMoves:'–';
  $('lf').textContent=a?puzzlePlaced()+'/'+puzzleBoxes.length:'–';
  $('bs').textContent=(a&&puzzleBest[puzzleLevel]&&puzzleBest[puzzleLevel].m)||'–';
 }
 const ov=$('ov');if(ov&&st!=='puzzlewon')ov.classList.remove('ov-clear');
}
function parsePuzzleLevel(n){
 const raw=puzzleMaps[(n-1)%puzzleMaps.length];puzzleRows=raw.length;puzzleCols=Math.max(...raw.map(r=>r.length));
 puzzleWalls=[];puzzleBoxes=[];puzzleGoals=[];puzzlePlayer={x:1,y:1};
 for(let y=0;y<raw.length;y++)for(let x=0;x<raw[y].length;x++){const ch=raw[y][x];
  if(ch==='#')puzzleWalls.push(x+','+y);if(ch==='@')puzzlePlayer={x,y};if(ch==='$')puzzleBoxes.push({x,y});if(ch==='.')puzzleGoals.push({x,y});
  if(ch==='*'){puzzleBoxes.push({x,y});puzzleGoals.push({x,y})}if(ch==='+'){puzzlePlayer={x,y};puzzleGoals.push({x,y})}}
 while(puzzleGoals.length<puzzleBoxes.length){let added=false;
  for(let y=1;y<puzzleRows-1&&!added;y++)for(let x=1;x<puzzleCols-1&&!added;x++){const key=x+','+y;
   if(!puzzleWalls.includes(key)&&!puzzleBoxes.some(b=>b.x===x&&b.y===y)&&!(puzzlePlayer.x===x&&puzzlePlayer.y===y)&&!puzzleGoals.some(g=>g.x===x&&g.y===y)){puzzleGoals.push({x,y});added=true}}
  if(!added)break}
 for(const b of puzzleBoxes){b.rx=b.x;b.ry=b.y}
 pzPR={x:puzzlePlayer.x,y:puzzlePlayer.y};pzParts=[];puzzleHint=null;puzzleHintUsed=false;puzzleLast={push:0,t:-9};puzzleBump={dx:0,dy:0,t:-9};
 puzzleMoves=0;puzzleHistory=[];puzzleLevel=n;puzzleActive=true;gameMode='puzzle';st='puzzleplay';
 const ov=$('ov');ov.style.display='none';ov.classList.remove('ov-clear');coachHide();hud();
}
function showPuzzleMenu(){
 gameMode='puzzle';st='puzzlemenu';puzzleActive=false;coachHide();
 const levels=Array.from({length:PZ_DONE},(_,i)=>{const n=i+1,bm=puzzleBest[n],raw=puzzleMaps[i].join(''),nbx=(raw.match(/[$*]/g)||[]).length;
  return '<button class="shop-item" data-puzzle-level="'+n+'">FASE '+n+'<small class="pz-st">'+(bm?'★'.repeat(bm.s)+'☆'.repeat(3-bm.s):'☆☆☆')+'</small><small>'+nbx+(nbx>1?' cx':' cx')+' · par '+puzzlePar[i]+'</small></button>'}).join('');
 let next=1;for(let i=1;i<=PZ_DONE;i++){next=i;if(!puzzleBest[i])break}
 const ov=$('ov');ov.classList.remove('ov-clear');
 ov.innerHTML='<div class="modern-menu-mark">🧩</div><h2>MODO PUZZLE</h2><p>Empurre todas as caixas para os alvos. Planeje cada movimento: você não pode puxar caixas!</p><div class="puzzle-levels">'+levels+'</div><div class="menu-actions"><button id="puzzleContinueBtn">JOGAR FASE '+next+'</button><button id="puzzleBackBtn" class="secondary">VOLTAR</button></div>';
 ov.style.display='flex';updateCampaignHud();
 ov.querySelectorAll('[data-puzzle-level]').forEach(b=>b.onclick=()=>parsePuzzleLevel(+b.dataset.puzzleLevel));
 $('puzzleContinueBtn').onclick=()=>parsePuzzleLevel(next);$('puzzleBackBtn').onclick=showModernSubmenu;
}
function savePuzzleHistory(){puzzleHistory.push(JSON.stringify({player:puzzlePlayer,boxes:puzzleBoxes.map(b=>({x:b.x,y:b.y})),moves:puzzleMoves,face:puzzleFace}));if(puzzleHistory.length>300)puzzleHistory.shift()}
function puzzleMove(dx,dy){
 if(!puzzleActive||st!=='puzzleplay')return;
 const nx=puzzlePlayer.x+dx,ny=puzzlePlayer.y+dy;if(dx)puzzleFace=dx;pzDir=dx?(dx>0?'r':'l'):(dy>0?'d':'u');
 const bump=()=>{puzzleBump={dx,dy,t:t};beep(140,.05,'square');buzz(8)};
 if(puzzleWalls.includes(nx+','+ny)){bump();return}
 const bi=puzzleBoxes.findIndex(b=>b.x===nx&&b.y===ny);
 if(bi>=0){const bx=nx+dx,by=ny+dy;
  if(puzzleWalls.includes(bx+','+by)||puzzleBoxes.some((b,i)=>i!==bi&&b.x===bx&&b.y===by)){bump();return}
  savePuzzleHistory();puzzleBoxes[bi].x=bx;puzzleBoxes[bi].y=by;puzzleLast={push:1,t:t};
 }else{savePuzzleHistory();puzzleLast={push:0,t:t}}
 puzzlePlayer={x:nx,y:ny};puzzleMoves++;puzzleHint=null;buzz(bi>=0?14:0);
 beep(bi>=0?520:340,.035,'triangle');hud();
 if(puzzleSolved())puzzleWin();
}
function puzzleUndo(){
 if(!puzzleActive||st!=='puzzleplay'||!puzzleHistory.length)return;
 const prev=JSON.parse(puzzleHistory.pop());puzzlePlayer=prev.player;puzzleMoves=prev.moves;puzzleFace=prev.face||puzzleFace;
 prev.boxes.forEach((b,i)=>{puzzleBoxes[i].x=b.x;puzzleBoxes[i].y=b.y});beep(260,.05,'triangle');hud();
}
function puzzleStars(m,lvl){const par=puzzlePar[lvl-1];let st=m<=Math.ceil(par*1.2)?3:m<=Math.ceil(par*1.7)?2:1;if(puzzleHintUsed)st=Math.min(st,2);return st}
function puzzleWin(){
 st='puzzlewon';puzzleHint=null;coachHide();
 const lvl=puzzleLevel,mv=puzzleMoves,stars=puzzleStars(mv,lvl),old=puzzleBest[lvl];
 const isRec=!old||mv<old.m||stars>old.s;
 if(isRec){puzzleBest[lvl]={m:old?Math.min(old.m,mv):mv,s:Math.max(old?old.s:0,stars)};try{localStorage.setItem(PZ_KEY,JSON.stringify(puzzleBest))}catch(e){}}
 hud();buzz([30,40,30,40,90]);
 const cols=['#ffb347','#ff6b35','#ffe36e','#ffffff','#43d9a3'];
 for(const b of puzzleBoxes)for(let i=0;i<14;i++)pzParts.push({gx:b.x,gy:b.y,x:0,y:0,vx:(Math.random()-.5)*340,vy:-120-Math.random()*260,life:.9+Math.random()*.8,c:cols[i%5],s:3+Math.random()*4,init:0});
 beep(520,.12,'triangle');setTimeout(()=>beep(660,.12,'triangle'),110);setTimeout(()=>beep(880,.22,'triangle'),230);
 const par=puzzlePar[lvl-1],hu=puzzleHintUsed;
 setTimeout(()=>{
  if(st!=='puzzlewon'||puzzleLevel!==lvl)return;
  const ov=$('ov');ov.classList.add('ov-clear');
  const starHtml=[1,2,3].map(i=>'<span class="'+(i<=stars?'on':'')+'" style="animation-delay:'+(i*.18)+'s">★</span>').join('');
  ov.innerHTML='<div class="puzzle-wrap"><span class="victory-label">'+(old&&!isRec?'FASE CONCLUÍDA':'NOVO RECORDE!')+'</span><h2>FASE '+lvl+' COMPLETA!</h2><div class="pz-stars">'+starHtml+'</div><p>'+mv+' movimentos · par '+par+(hu?' · com dica (máx. 2★)':'')+(old&&!isRec?'<br>Seu melhor: '+old.m+' mov. '+'★'.repeat(old.s):'')+'</p><div class="puzzle-actions"><button id="pNextBtn">'+(lvl<PZ_DONE?'PRÓXIMA FASE ➜':'RECOMEÇAR')+'</button><button id="pReplayBtn" class="secondary">REPETIR</button><button id="pLevelsBtn2" class="secondary">FASES</button></div></div>';
  ov.style.display='flex';
  $('pNextBtn').onclick=()=>parsePuzzleLevel(lvl<PZ_DONE?lvl+1:1);$('pReplayBtn').onclick=()=>parsePuzzleLevel(lvl);$('pLevelsBtn2').onclick=showPuzzleMenu;
 },750);
}
// Solver do puzzle (Dijkstra sobre empurrões): devolve a lista de passos [dx,dy] ótima a partir do estado atual.
function pzSolve(cap){
 cap=cap||250000;
 const C=puzzleCols,R=puzzleRows,N=C*R,DIR=[[1,0],[-1,0],[0,1],[0,-1]];
 const wall=new Uint8Array(N),goal=new Uint8Array(N),dead=new Uint8Array(N);
 puzzleWalls.forEach(k=>{const q=k.split(',');wall[+q[1]*C+ +q[0]]=1});
 puzzleGoals.forEach(g=>{goal[g.y*C+g.x]=1});
 const W=(x,y)=>x<0||y<0||x>=C||y>=R||wall[y*C+x]===1;
 for(let y=0;y<R;y++)for(let x=0;x<C;x++){const i=y*C+x;if(wall[i]||goal[i])continue;
  if((W(x+1,y)||W(x-1,y))&&(W(x,y+1)||W(x,y-1)))dead[i]=1}
 const occ=new Uint8Array(N);
 function bfs(boxes,p){occ.fill(0);for(const b of boxes)occ[b]=1;const dist=new Int16Array(N).fill(-1);dist[p]=0;const q=[p];
  for(let h=0;h<q.length;h++){const c=q[h],cx0=c%C,cy0=(c/C)|0;for(const d of DIR){const nx=cx0+d[0],ny=cy0+d[1];if(W(nx,ny))continue;const n=ny*C+nx;if(occ[n]||dist[n]>=0)continue;dist[n]=dist[c]+1;q.push(n)}}return dist}
 const b0=puzzleBoxes.map(b=>b.y*C+b.x).sort((a,b)=>a-b),p0=puzzlePlayer.y*C+puzzlePlayer.x;
 const done=b=>b.every(i=>goal[i]===1);
 if(done(b0))return[];
 const heap=[];const push=(it)=>{heap.push(it);let i=heap.length-1;while(i>0){const p=(i-1)>>1;if(heap[p][0]<=heap[i][0])break;[heap[p],heap[i]]=[heap[i],heap[p]];i=p}};
 const pop=()=>{const top=heap[0],last=heap.pop();if(heap.length){heap[0]=last;let i=0;for(;;){let l=2*i+1,r=l+1,m=i;if(l<heap.length&&heap[l][0]<heap[m][0])m=l;if(r<heap.length&&heap[r][0]<heap[m][0])m=r;if(m===i)break;[heap[m],heap[i]]=[heap[i],heap[m]];i=m}}return top};
 const info=new Map();const k0=b0.join(',')+'|'+p0;info.set(k0,{d:0,prev:null,mv:null,boxes:b0,p:p0});push([0,k0]);
 let cnt=0,goalKey=null;
 while(heap.length){
  const [d,key]=pop();const st=info.get(key);if(st.d<d)continue;
  if(done(st.boxes)){goalKey=key;break}
  if(++cnt>cap)return null;
  const dist=bfs(st.boxes,st.p);
  for(let bi=0;bi<st.boxes.length;bi++){const b=st.boxes[bi],bx=b%C,by=(b/C)|0;
   for(let di=0;di<4;di++){const dx=DIR[di][0],dy=DIR[di][1];
    const sx=bx-dx,sy=by-dy,tx=bx+dx,ty=by+dy;
    if(W(sx,sy)||W(tx,ty))continue;const s=sy*C+sx,t=ty*C+tx;
    if(dist[s]<0||dead[t])continue;
    let blocked=false;for(const o of st.boxes)if(o===t){blocked=true;break}if(blocked)continue;
    const nb=st.boxes.slice();nb[bi]=t;nb.sort((a,c)=>a-c);
    const nk=nb.join(',')+'|'+b,nd=d+dist[s]+1,ex=info.get(nk);
    if(!ex||nd<ex.d){info.set(nk,{d:nd,prev:key,mv:[b,di],boxes:nb,p:b});push([nd,nk])}}}
 }
 if(!goalKey)return null;
 const pushes=[];for(let k=goalKey;info.get(k).prev;k=info.get(k).prev)pushes.push(info.get(k).mv);pushes.reverse();
 // reconstrói os passos de caminhada
 const out=[];let pos=p0,boxes=b0.slice();
 for(const [from,di] of pushes){
  const dx=DIR[di][0],dy=DIR[di][1],s=((from/C|0)-dy)*C+(from%C-dx);
  occ.fill(0);for(const b of boxes)occ[b]=1;
  const par=new Int16Array(N).fill(-2);par[pos]=-1;const q=[pos];
  for(let h=0;h<q.length&&par[s]===-2;h++){const c=q[h];for(let k=0;k<4;k++){const nx=c%C+DIR[k][0],ny=((c/C)|0)+DIR[k][1];if(W(nx,ny))continue;const n=ny*C+nx;if(occ[n]||par[n]!==-2)continue;par[n]=c*4+k;q.push(n)}}
  const walk=[];for(let c=s;par[c]!==-1;){const pk=par[c];walk.push(DIR[pk%4]);c=(pk/4)|0}
  walk.reverse();for(const w of walk)out.push(w);out.push([dx,dy]);
  boxes=boxes.map(b=>b===from?from+dy*C+dx:b);pos=from;
 }
 return out;
}

function puzzleHintNow(){
 if(!puzzleActive||st!=='puzzleplay')return;
 const path=pzSolve();
 if(path===null){coach('Sem saída a partir daqui. Desfaça ou reinicie.',2600);buzz(20);return}
 if(!path.length)return;
 puzzleHint={dir:path[0],t0:t,left:path.length};puzzleHintUsed=true;beep(700,.06,'triangle');
 coach('Dica: siga a seta (faltam '+path.length+' movimentos). Fase passa a dar no máximo 2★.',2600);
}
let coachTimer=0;
function coach(text,ms){ms=ms||6500;const c=$('coach');if(!c)return;c.textContent=text;c.classList.add('low');c.classList.add('show');clearTimeout(coachTimer);if(ms)coachTimer=setTimeout(()=>c.classList.remove('show'),ms)}
function coachHide(){const c=$('coach');if(c)c.classList.remove('show')}
function pzRR(g,x,y,w,h,r){g.beginPath();g.moveTo(x+r,y);g.arcTo(x+w,y,x+w,y+h,r);g.arcTo(x+w,y+h,x,y+h,r);g.arcTo(x,y+h,x,y,r);g.arcTo(x,y,x+w,y,r);g.closePath()}
function pzWall(g,x,y,ts,gx,gy){
 const gr=g.createLinearGradient(0,y,0,y+ts);gr.addColorStop(0,'#7388ad');gr.addColorStop(.14,'#53688f');gr.addColorStop(1,'#242f4c');
 pzRR(g,x+1,y+1,ts-2,ts-2,5);g.fillStyle=gr;g.fill();g.strokeStyle='#121a31';g.lineWidth=2;g.stroke();
 g.strokeStyle='rgba(12,18,38,.5)';g.lineWidth=2;g.beginPath();
 g.moveTo(x+4,y+ts/2);g.lineTo(x+ts-4,y+ts/2);
 const o=(gx+gy)%2?.32:.68;g.moveTo(x+ts*o,y+4);g.lineTo(x+ts*o,y+ts/2);
 g.moveTo(x+ts*(1-o),y+ts/2);g.lineTo(x+ts*(1-o),y+ts-4);g.stroke();
 g.fillStyle='rgba(255,255,255,.22)';g.fillRect(x+5,y+3,ts-10,2);
 g.fillStyle='#ffb65c';for(const [rx,ry] of [[7,7],[ts-7,7],[7,ts-7],[ts-7,ts-7]]){g.beginPath();g.arc(x+rx,y+ry,1.6,0,6.3);g.fill()}
}
function drawPuzzle(){
 const dt=Math.min(.05,Math.max(0,t-pzDrawT));pzDrawT=t;const g=cx;
 g.clearRect(0,0,656,520);g.drawImage(IM.bg,0,0);
 g.fillStyle='rgba(6,9,24,.38)';g.fillRect(16,24,624,468);
 const cols=puzzleCols,rows=puzzleRows,ts=Math.floor(Math.min(596/cols,440/rows)),bw=cols*ts,bh=rows*ts,ox=Math.round((656-bw)/2),oy=Math.round(24+(468-bh)/2);
 const k=Math.min(1,dt*16);
 for(const b of puzzleBoxes){if(b.rx===undefined){b.rx=b.x;b.ry=b.y}b.rx+=(b.x-b.rx)*k;b.ry+=(b.y-b.ry)*k}
 pzPR.x+=(puzzlePlayer.x-pzPR.x)*k;pzPR.y+=(puzzlePlayer.y-pzPR.y)*k;
 // moldura do tabuleiro
 g.save();g.shadowColor='rgba(255,150,40,.45)';g.shadowBlur=22;
 const pg=g.createLinearGradient(0,oy,0,oy+bh);pg.addColorStop(0,'#1a2342');pg.addColorStop(1,'#0e1428');
 pzRR(g,ox-10,oy-10,bw+20,bh+20,14);g.fillStyle=pg;g.fill();g.restore();
 pzRR(g,ox-10,oy-10,bw+20,bh+20,14);g.strokeStyle='#ffb65c';g.lineWidth=3;g.stroke();
 const pulse=.5+.5*Math.sin(t*(st==='puzzlewon'?8:3));
 // piso + alvos
 for(let y=0;y<rows;y++)for(let x=0;x<cols;x++){
  if(puzzleWalls.includes(x+','+y))continue;
  const px=ox+x*ts,py=oy+y*ts;
  g.fillStyle=(x+y)%2?'#1d2a4a':'#18233f';g.fillRect(px,py,ts,ts);
  g.strokeStyle='rgba(120,160,230,.12)';g.lineWidth=1;g.strokeRect(px+.5,py+.5,ts-1,ts-1);
  g.fillStyle='rgba(160,190,255,.14)';for(const [rx,ry] of [[5,5],[ts-5,5],[5,ts-5],[ts-5,ts-5]]){g.fillRect(px+rx-1,py+ry-1,2,2)}
  if(puzzleGoals.some(q=>q.x===x&&q.y===y)){
   {const T=PZS['tgt'+(Math.floor(t*3)%4)],w=ts*.82,h=T.height/T.width*w;g.globalAlpha=.8+.2*pulse;g.drawImage(T,px+(ts-w)/2,py+(ts-h)/2,w,h);g.globalAlpha=1}
  }
 }
 for(let y=0;y<rows;y++)for(let x=0;x<cols;x++)if(puzzleWalls.includes(x+','+y))pzWall(g,ox+x*ts,oy+y*ts,ts,x,y);
 // entidades ordenadas por profundidade
 const ents=puzzleBoxes.map(b=>({y:b.ry,b}));ents.push({y:pzPR.y+.01,p:1});ents.sort((a,b)=>a.y-b.y);
 for(const e of ents){
  if(e.b){
   const b=e.b;if(pzHide(b))continue;const on=puzzleGoals.some(q=>q.x===b.x&&q.y===b.y),px=ox+b.rx*ts,py=oy+b.ry*ts;
   g.fillStyle='rgba(0,0,0,.35)';g.beginPath();g.ellipse(px+ts/2,py+ts-4,ts*.4,ts*.1,0,0,6.3);g.fill();
   if(on){const rg=g.createRadialGradient(px+ts/2,py+ts/2,ts*.2,px+ts/2,py+ts/2,ts*.85);rg.addColorStop(0,'rgba(67,217,163,'+(.5+.25*pulse)+')');rg.addColorStop(1,'rgba(67,217,163,0)');g.fillStyle=rg;g.fillRect(px-ts*.4,py-ts*.4,ts*1.8,ts*1.8)}
   {const q=PZS[(on?'boxt':'box')+(Math.floor(t*3)%4)],w=ts*(on?1.08:.95),h=q.height/q.width*w;g.drawImage(q,px+(ts-w)/2,py+ts-h+ts*.05,w,h)}
  }else{
   let sx=ox+pzPR.x*ts+ts/2,sy=oy+(pzPR.y+1)*ts-3;
   const bt=t-puzzleBump.t;if(bt<.18){const a=Math.sin(bt/.18*Math.PI)*5;sx+=puzzleBump.dx*a;sy+=puzzleBump.dy*a}
   const moving=Math.abs(pzPR.x-puzzlePlayer.x)>.04||Math.abs(pzPR.y-puzzlePlayer.y)>.04;
   const u=ts*1.5/113,D=pzDir,f=Math.floor(t*10)%4;let im,ax=.5,hop=0;
   g.fillStyle='rgba(0,0,0,.38)';g.beginPath();g.ellipse(sx,sy-1,ts*.32,ts*.09,0,0,6.3);g.fill();
   if(st==='puzzlewon'){im=PZS['win'+(Math.floor(t*4)%2)];hop=-Math.abs(Math.sin(t*7))*8}
   else if(bt<.3)im=PZS['hurt'+(Math.floor(t*10)%2)];
   else if(moving&&puzzleLast.push&&D!=='d'){im=PZS['p'+D+f];ax=D==='l'?.68:D==='r'?.32:.5}
   else if(moving)im=PZS['w'+D+f];
   else if(puzzleHint)im=PZS['think'+(Math.floor(t*3)%2)];
   else im=D==='d'?PZS['idle'+(Math.floor(t*3)%4)]:PZS['w'+D+'0'];
   pzSpr(g,im,ax,sx,sy+ts*.06+hop,u);
  }
 }

 if(puzzleHint&&t-puzzleHint.t0<3.2){const h=puzzleHint,bob=Math.sin((t-h.t0)*9)*4,ax=ox+pzPR.x*ts+ts/2+h.dir[0]*(ts*.78+bob),ay=oy+pzPR.y*ts+ts/2+h.dir[1]*(ts*.78+bob);
  g.save();g.translate(ax,ay);g.rotate(Math.atan2(h.dir[1],h.dir[0]));g.fillStyle='#ffe36e';g.strokeStyle='#7a4a00';g.lineWidth=2;
  g.beginPath();g.moveTo(ts*.22,0);g.lineTo(-ts*.12,-ts*.2);g.lineTo(-ts*.12,ts*.2);g.closePath();g.fill();g.stroke();g.restore();
  const hx=puzzlePlayer.x+h.dir[0],hy=puzzlePlayer.y+h.dir[1],hb=puzzleBoxes.find(b=>b.x===hx&&b.y===hy);
  if(hb){g.strokeStyle='rgba(255,227,110,'+(.6+.4*Math.sin(t*10))+')';g.lineWidth=4;pzRR(g,ox+hb.rx*ts+1,oy+hb.ry*ts+1,ts-2,ts-2,6);g.stroke()}
 }else if(puzzleHint)puzzleHint=null;
 // confete da vitória
 for(const p of pzParts){if(!p.init){p.x=ox+p.gx*ts+ts/2;p.y=oy+p.gy*ts+ts/2;p.init=1}p.life-=dt;p.vy+=520*dt;p.x+=p.vx*dt;p.y+=p.vy*dt;
  if(p.life>0){g.globalAlpha=Math.min(1,p.life*2);g.fillStyle=p.c;g.fillRect(p.x,p.y,p.s,p.s)}}
 g.globalAlpha=1;pzParts=pzParts.filter(p=>p.life>0);
 g.drawImage(IM.ceil,0,0);
}
const classicDraw=draw;draw=function(){if(ld<nI)return;if(gameMode==='puzzle'&&puzzleActive){if(pzReady>=pzN)drawPuzzle();return}classicDraw()};
// controles do puzzle (direcional + ações) substituem os botões ◀ ▶ ▲ da tela
document.querySelectorAll('[data-pdir]').forEach(b=>{
 const [dx,dy]=b.dataset.pdir.split(',').map(Number);let to=0,rp=0;
 const stop=()=>{clearTimeout(to);clearInterval(rp);b.classList.remove('on')};
 b.addEventListener('pointerdown',e=>{e.preventDefault();try{b.setPointerCapture(e.pointerId)}catch(_){}stop();b.classList.add('on');puzzleMove(dx,dy);to=setTimeout(()=>{rp=setInterval(()=>puzzleMove(dx,dy),150)},280)});
 ['pointerup','pointercancel','lostpointercapture'].forEach(ev=>b.addEventListener(ev,stop));
});
$('pUndoBtn').onclick=puzzleUndo;$('pHintBtn').onclick=puzzleHintNow;
$('pResetBtn').onclick=()=>{if(puzzleActive)parsePuzzleLevel(puzzleLevel)};
$('pLevelsBtn').onclick=showPuzzleMenu;
$('pExitBtn').onclick=showModernSubmenu;
addEventListener('keydown',e=>{if(gameMode!=='puzzle'||!puzzleActive)return;if(st==='puzzlewon'&&e.key==='Enter'&&$('pNextBtn')){e.preventDefault();$('pNextBtn').click()}});

function showModeMenu(){st='title';$('ov').innerHTML='<h2>STACK ATTACK</h2><p>Escolha como quer jogar.</p><p>Clássico: partida tradicional. Moderno: escolha entre Sobrevivência, Campanha e Puzzle.</p><div class="menu-actions"><button id="classicModeBtn">CLÁSSICO</button><button id="modernModeBtn">MODERNO</button></div>';$('ov').style.display='flex';$('classicModeBtn').onclick=()=>{gameMode='classic';updateCampaignHud();$('ov').innerHTML='<h2>STACK ATTACK</h2><p>Empurre as caixas e complete uma linha inteira de 12 para limpá-la. Pule para subir nas caixas. Não deixe a pilha chegar ao topo e não seja esmagado!</p><p>← → mover · ↑ pular · P pausa</p><button id="ob">JOGAR</button><button id="backMode" class="secondary">VOLTAR</button>';$('ob').onclick=()=>start()};$('modernModeBtn').onclick=showModernSubmenu;updateCampaignHud()}
function showModernSubmenu(){gameMode='modern';updateCampaignHud();st='title';$('ov').innerHTML='<h2>⚡ MODO <span id=\"cheatWord\" style=\"user-select:none;-webkit-user-select:none;touch-action:manipulation\">MODERNO</span></h2><p>Escolha sua experiência de jogo.</p><div class="mcards"><button class="mcard surv" id="survivalModeBtn"><b>SOBREVIVÊNCIA</b><small>Sem missões. Recorde de pontos.</small></button><button class="mcard camp" id="campaignModeBtn"><b>CAMPANHA</b><small>Fases, objetivos e poderes.</small></button><button class="mcard puz" id="puzzleModeBtn"><b>PUZZLE</b><small>Caixas, lógica e desafios.</small></button></div><button id="modernBackBtn" class="secondary wide">← VOLTAR</button>';$('ov').style.display='flex';$('survivalModeBtn').onclick=showSurvivalIntro;$('campaignModeBtn').onclick=openCampaign;$('modernBackBtn').onclick=showModeMenu;$('puzzleModeBtn').onclick=showPuzzleMenu}
function openCampaign(){if(!tutDone)startTutorial();else showCampaignMenu()}
function showSurvivalIntro(){gameMode='survival';updateCampaignHud();st='title';$('ov').innerHTML='<h2>♾️ SOBREVIVÊNCIA</h2><p>Sem missões e sem fases: sobreviva o máximo de tempo possível e faça a maior pontuação.</p><p>⚡ Os poderes Escudo e Salto Duplo ficam ativos por 30 segundos após serem usados. Ative-os durante a partida.</p><div class="menu-actions"><button id="startSurvivalBtn">COMEÇAR</button><button id="survivalBackBtn" class="secondary">VOLTAR</button></div>';$('ov').style.display='flex';$('startSurvivalBtn').onclick=startSurvival;$('survivalBackBtn').onclick=showModernSubmenu}
function showCampaignMenu(){gameMode='modern';updateCampaignHud();st='title';const buttons=stageInfo.map((s,i)=>'<button class="shop-item" data-stage="'+(i+1)+'" '+(i+1>unlockedStage?'disabled style="opacity:.4"':'')+'>FASE '+(i+1)+'<small>'+s.name+(i+1>unlockedStage?' · BLOQUEADA':'')+'</small><small>'+s.desc+'</small></button>').join('');$('ov').innerHTML='<h2>🏆 CAMPANHA</h2><p>Ganhe 5 moedas por linha. Moedas e fases desbloqueadas são salvas neste navegador.</p><div class="shop-grid">'+buttons+'</div><p>Moedas: <b>'+coins+'</b></p><div class="menu-actions"><button id="campaignShopBtn" class="secondary">LOJA DE PODERES</button><button id="campaignBackBtn" class="secondary">VOLTAR</button></div>';$('ov').style.display='flex';$('ov').querySelectorAll('[data-stage]').forEach(b=>b.onclick=()=>{campaignStage=+b.dataset.stage;saveCampaign();startModernStage()});$('campaignShopBtn').onclick=()=>{shopReturnState='title';openShop()};$('campaignBackBtn').onclick=showModernSubmenu}
function startSurvival(){gameMode='survival';classicStart();activeEffects={};powerInventory={shield:1,jump:1};shieldReady=false;doubleJumpReady=false;survivalPowerTimers={shield:0,jump:0};survivalElapsed=0;lineBursts=[];const screen=$('ov');screen.style.display='none';updateCampaignHud();renderPowerButtons();hud()}
const classicStart=start;start=function(){if(gameMode==='modern'){startModernStage();return}if(gameMode==='survival'){startSurvival();return}classicStart()};
function startModernStage(){const s=campaignStage;classicStart();campaignStage=s;stageRows=0;stageStartedAt=t;activeEffects={};if(!preservePowersForNextStage)powerInventory={};preservePowersForNextStage=false;shieldReady=false;doubleJumpReady=false;lineBursts=[];stageHits=0;stageStartY=P.y;maxHeightReached=P.y;floorsClimbed=0;stageFailed=false;stageHudClock=0;stageSurvivalTime=0;if(campaignStage===4)nextCol=P.x;updateCampaignHud();saveCampaign()}
const classicStep=step;step=function(dt){if(gameMode==='survival'&&st==='play'){survivalElapsed+=dt;for(const id of ['shield','jump']){if(activeEffects[id]>0){activeEffects[id]=Math.max(0,activeEffects[id]-dt);survivalPowerTimers[id]=activeEffects[id];if(activeEffects[id]===0){delete activeEffects[id];if(id==='shield')shieldReady=false;if(id==='jump')doubleJumpReady=false;}}}classicStep(dt);if(survivalElapsed%1<dt){const ov=$('survivalTime');if(ov)ov.textContent=Math.floor(survivalElapsed)+'s';}renderPowerButtons();return}if(gameMode!=='modern'||st!=='play'){classicStep(dt);return}const beforeY=P.y;if(campaignStage===4)stageSurvivalTime+=dt;classicStep(dt);if(sup())doubleJumpReady=activeEffects.jump>0;if(P.y>beforeY)floorsClimbed+=P.y-beforeY;maxHeightReached=Math.max(maxHeightReached,P.y);if(campaignStage===2&&maxHeightReached-stageStartY>=stageInfo[1].goal)completeStage();if(campaignStage===5&&maxHeightReached>=H-3)completeStage();if(campaignStage===4){const cfg=stageInfo[3];if(stageSurvivalTime>=cfg.time)completeStage()}if(campaignStage===3&&stageRows>=stageInfo[2].goal)completeStage();if(campaignStage===1&&stageRows>=stageInfo[0].goal)completeStage();if(campaignStage===2)iv=Math.min(iv,2.0);if(campaignStage===3)iv=Math.min(iv,1.8);if(campaignStage===4)iv=Math.min(iv,1.45);if(campaignStage===5)iv=Math.min(iv,1.2);for(const burst of lineBursts){burst.age+=dt;for(const q of burst.particles){q.x+=q.vx*dt;q.y+=q.vy*dt;q.vy-=9*dt;q.life-=dt}}lineBursts=lineBursts.filter(b=>b.age<.75);stageHudClock+=dt;if(stageHudClock>=.2){stageHudClock=0;updateObjectiveHud()}}
function failModernStage(reason){if(st!=='play')return;stageFailed=true;st='stagefailed';saveCampaign();$('ov').innerHTML='<h2>FASE NÃO CONCLUÍDA</h2><p>'+reason+'</p><p>Você sobreviveu por '+Math.max(0,Math.floor(t-stageStartedAt))+' de 120 segundos.</p><div class="menu-actions"><button id="retryFailedStage">TENTAR NOVAMENTE</button><button id="failedCampaignMenu" class="secondary">MENU DA CAMPANHA</button></div>';$('ov').style.display='flex';$('retryFailedStage').onclick=startModernStage;$('failedCampaignMenu').onclick=showCampaignMenu;updateCampaignHud()}
const classicGravity=gravity;gravity=function(){const old=rows;classicGravity();const n=rows-old;if(gameMode==='modern'&&n>0){stageRows+=n;coins+=n*5;saveCampaign();if((campaignStage===1||campaignStage===3)&&stageRows>=stageInfo[campaignStage-1].goal)completeStage()}};
const classicCrush=crush;crush=function(){if(gameMode==='modern'&&campaignStage===4){stageHits++;return failModernStage('Uma caixa atingiu você. Nesta fase, não pode ser atingido nenhuma vez.')}classicCrush()};
const classicOver=over;over=function(){if(gameMode!=='modern'){classicOver();return}st='over';P.dead=t;if(score>best){best=score;try{localStorage.setItem('sa_best',best)}catch(e){}}hud();$('ov').innerHTML='<h2>SEM VIDAS</h2><p>Fase '+campaignStage+' · Progresso: '+stageRows+'/'+stageInfo[campaignStage-1].goal+' linhas.<br>Saldo: '+coins+' moedas.</p><div class="menu-actions"><button id="buyAttempt" '+(coins<100?'disabled':'')+'>VIDA EXTRA · 100 🪙</button><button id="restartStage" class="secondary">REINICIAR FASE</button></div><button id="campaignMenuBtn" class="secondary">MENU DA CAMPANHA</button>';$('ov').style.display='flex';$('buyAttempt').onclick=()=>{if(coins<100)return;coins-=100;lives=1;P.dead=0;spawnP();P.hit=.8;spawnT=-1;gT=0;st='play';$('ov').style.display='none';saveCampaign();hud()};$('restartStage').onclick=startModernStage;$('campaignMenuBtn').onclick=showCampaignMenu};
function completeStage(){
 if(st!=='play')return;
 st='stagecomplete';
 const n=campaignStage,allDone=n===5;
 coins+=25;unlockedStage=Math.max(unlockedStage,Math.min(5,n+1));saveCampaign();beep(880,.18);
 const result=n===2?'Altura alcançada: '+Math.max(0,maxHeightReached-stageStartY)+' andares':n===4?'Sobreviveu 120 segundos sem ser atingido por nenhuma caixa':n===5?'Altura máxima alcançada: '+maxHeightReached+' andares':'Linhas concluídas: '+stageRows;
 $('ov').innerHTML='<div class="victory-confetti" aria-hidden="true"><span>✨</span><span>🎉</span><span>⭐</span><span>🎊</span><span>✨</span></div><div class="victory-art" aria-hidden="true">'+(allDone?'🏆':'🎉')+'</div><span class="victory-label">'+(allDone?'CAMPANHA COMPLETA':'OBJETIVO ALCANÇADO')+'</span><h2>'+(allDone?'CAMPANHA CONCLUÍDA!':'FASE CONCLUÍDA!')+'</h2><div class="victory-progress" aria-label="Progresso da campanha"><span style="width:'+(n/5*100)+'%"></span></div><p><b>FASE '+n+' / 5 — '+stageInfo[n-1].name+'</b><br>'+result+'<br><b>🎁 Bônus: +25 moedas</b><br>Saldo: '+coins+' moedas.</p><div class="menu-actions"><button id="nextStageBtn">'+(allDone?'JOGAR NOVAMENTE':'PRÓXIMA FASE ➜')+'</button><button id="campaignShopBtn" class="secondary">⚡ LOJA</button></div><button id="campaignMenuBtn" class="secondary">MENU DA CAMPANHA</button>';
 $('ov').style.display='flex';
 stageCompleteStage=n;stageCompleteMarkup=$('ov').innerHTML;bindStageCompleteButtons(n);
 updateCampaignHud();
}
function bindStageCompleteButtons(n){
 $('nextStageBtn').onclick=()=>{campaignStage=n===5?1:n+1;saveCampaign();startModernStage()};
 $('campaignShopBtn').onclick=()=>{shopReturnState='stagecomplete';openShop()};
 $('campaignMenuBtn').onclick=showCampaignMenu;
}
function openShop(){st='shop';const items=shopItems.map(it=>'<button class="shop-item" data-buy="'+it.id+'" '+(coins<it.price?'disabled':'')+'>'+it.name+'<small>'+it.price+' moedas</small><small>'+it.desc+'</small></button>').join('');$('ov').innerHTML='<h2>⚡ HABILIDADES</h2><p>Escolha entre escudo de uso único e salto duplo. Ao comprar, um botão aparece na partida para ativar a habilidade. Saldo: '+coins+' moedas</p><div class="shop-grid">'+items+'</div><button id="closeShop" class="secondary wide">VOLTAR</button>';$('ov').style.display='flex';$('ov').querySelectorAll('[data-buy]').forEach(b=>b.onclick=()=>buyItem(b.dataset.buy));$('closeShop').onclick=closeShop}
function closeShop(){$('ov').style.display='none';if(shopReturnState==='title'){showCampaignMenu();return}if(shopReturnState==='stagecomplete'){st='stagecomplete';$('ov').innerHTML=stageCompleteMarkup;$('ov').style.display='flex';bindStageCompleteButtons(stageCompleteStage);return}st='play';updateCampaignHud()}
function buyItem(id){
 const it=shopItems.find(x=>x.id===id);if(!it||coins<it.price)return;
 if(id==='life'&&lives>=3){openShop();const mp=$('ov').querySelector('p');if(mp)mp.textContent='Você já está com 3 vidas.';return}
 coins-=it.price;powerInventory[id]=(powerInventory[id]||0)+1;if(shopReturnState==='title'||shopReturnState==='stagecomplete')preservePowersForNextStage=true;
 saveCampaign();beep(740,.1);openShop()
}
function activatePower(id){
 if(!['modern','survival'].includes(gameMode)||st!=='play'||!['shield','jump'].includes(id))return;
 if(gameMode==='modern'&&!powerInventory[id])return;
 if(gameMode==='modern'){powerInventory[id]--;if(powerInventory[id]<=0)delete powerInventory[id]}
 if(id==='shield'){shieldReady=true;activeEffects.shield=gameMode==='survival'?30:1}
 if(id==='jump'){activeEffects.jump=gameMode==='survival'?30:1;doubleJumpReady=false}
 if(gameMode==='survival')survivalPowerTimers[id]=30;
 saveCampaign();beep(740,.1);renderPowerButtons();updateCampaignHud()
}
const classicMove=tryMove;tryMove=function(d){return classicMove(d)};
const classicJump=()=>{};
$('shopBtn').onclick=()=>{if(gameMode==='modern'&&st==='play'){shopReturnState='play';openShop()}};const baseHud=hud;hud=function(){baseHud();updateCampaignHud()};// ---- Efeitos, música reativa e tutorial ----
let pops=[],tutDone=false,tut=null,tutTimer=0;
try{tutDone=!!localStorage.getItem('sa_tut')}catch(e){}
const jGravity=gravity;gravity=function(){const s0=score;jGravity();if(score>s0){pops.push({text:'+'+(score-s0),age:0});buzz([25,30,50]);cv.classList.remove('shake');void cv.offsetWidth;cv.classList.add('shake')}};
const jCrush=crush;crush=function(){buzz([70,40,110]);jCrush()};
const jMove=tryMove;tryMove=function(d){const r=jMove(d);if(r&&P.busy===.18)buzz(10);return r};
const jPause=pause;pause=function(){jPause();if(st==='pause'){const b=document.createElement('button');b.className='secondary';b.textContent='MENU DE MODOS';b.onclick=()=>{showModernSubmenu()};$('ov').appendChild(b)}};
function stackDanger(){let m=0;for(const b of boxes)if(b.s&&b.y+1>m)m=b.y+1;return Math.min(1,m/H)}
const jDraw=draw;draw=function(){
 jDraw();
 if(gameMode==='puzzle'||ld<nI)return;
 if(st==='play'){const dg=stackDanger();if(dg>=.6){const a=(dg-.55)*.5*(.6+.4*Math.sin(t*(6+dg*8)));const gr=cx.createRadialGradient(328,260,170,328,260,420);gr.addColorStop(0,'rgba(255,40,20,0)');gr.addColorStop(1,'rgba(255,40,20,'+Math.max(0,a)+')');cx.fillStyle=gr;cx.fillRect(0,0,656,520)}}
 if(pops.length){const dt=1/60;for(const p of pops){p.age+=dt;const k=p.age/1.1;cx.save();cx.globalAlpha=Math.max(0,1-k);cx.textAlign='center';cx.font='900 '+Math.round(34+10*Math.min(1,k*4))+'px ui-monospace,monospace';cx.lineWidth=6;cx.strokeStyle='#5a2400';cx.fillStyle='#ffe36e';const y=240-k*80;cx.strokeText(p.text,328,y);cx.fillText(p.text,328,y);cx.restore()}pops=pops.filter(p=>p.age<1.1)}
};
// música: baixo + arpejo; o andamento acelera conforme a pilha sobe
const MUS_BASS=[110,110,131,110,98,98,123,98],MUS_ARP=[440,523,659,523,392,494,587,494];let musStep=0;
function musicTick(){
 let delay=300;
 const playing=st==='play'&&gameMode!=='puzzle',calm=st==='puzzleplay';
 if(!mute&&ac&&ac.state==='running'&&(playing||calm)){
  const dg=playing?stackDanger():0;delay=calm?420:Math.round(280-150*dg);
  const f=MUS_BASS[musStep%8];
  try{const o=ac.createOscillator(),g=ac.createGain();o.type='triangle';o.frequency.value=f;g.gain.setValueAtTime(.045,ac.currentTime);g.gain.exponentialRampToValueAtTime(.0008,ac.currentTime+delay/1000*.9);o.connect(g);g.connect(ac.destination);o.start();o.stop(ac.currentTime+delay/1000)}catch(e){}
  if(calm||dg>.35||musStep%2===1){try{const o=ac.createOscillator(),g=ac.createGain();o.type=calm?'sine':'square';o.frequency.value=MUS_ARP[musStep%8]*(dg>.7?1.5:1);g.gain.setValueAtTime(calm?.018:.012,ac.currentTime);g.gain.exponentialRampToValueAtTime(.0005,ac.currentTime+.12);o.connect(g);g.connect(ac.destination);o.start();o.stop(ac.currentTime+.13)}catch(e){}}
  musStep++;
 }
 setTimeout(musicTick,delay);
}
setTimeout(musicTick,600);
// tutorial de abertura
function tutEnd(){tut=null;clearInterval(tutTimer);coachHide();if(!tutDone){tutDone=true;try{localStorage.setItem('sa_tut','1')}catch(e){}}}
function tutShow(){const txt=['<b>1/4 · Mover:</b> use ◀ ▶ para andar.','<b>2/4 · Pular:</b> toque ▲ para subir numa caixa.','<b>3/4 · Empurrar:</b> ande contra uma caixa para empurrá-la.','<b>4/4 · Objetivo:</b> alinhe 12 caixas lado a lado para eliminar a linha. Não deixe a pilha chegar ao topo!'][tut.step];const c=$('coach');c.classList.remove('low');c.innerHTML=txt+' <span class="skip" id="tutSkip">PULAR</span>';c.classList.add('show');$('tutSkip').onclick=tutEnd}
function startTutorial(){
 gameMode='modern';campaignStage=1;startModernStage();
 tut={step:0,x0:P.x,t0:t};tutShow();
 clearInterval(tutTimer);tutTimer=setInterval(()=>{
  if(!tut)return;if(st==='title'||gameMode!=='modern'){tutEnd();return}if(st!=='play')return;
  if(tut.step===0&&Math.abs(P.x-tut.x0)>=1){tut.step=1;tutShow();buzz(15)}
  else if(tut.step===1&&P.y>=1){tut.step=2;tutShow();buzz(15)}
  else if(tut.step===2&&(P.anim==='pl'||P.anim==='pr')){tut.step=3;tut.t0=t;tutDone=true;try{localStorage.setItem('sa_tut','1')}catch(e){}tutShow();buzz(15)}
  else if(tut.step===3&&(stageRows>0||t-tut.t0>30))tutEnd();
 },90);
}

gameMode='modern';showModernSubmenu();

let last=0;function loop(ts){if(document.body.dataset.st!==st)document.body.dataset.st=st;if(document.body.dataset.mode!==gameMode)document.body.dataset.mode=gameMode;const dt=Math.min(.05,(ts-last)/1000||0);last=ts;t+=dt;if(st=='play')step(dt);draw();requestAnimationFrame(loop)}
const K={ArrowLeft:'l',a:'l',A:'l',ArrowRight:'r',d:'r',D:'r'};
addEventListener('keydown',e=>{if(puzzleActive&&st==='puzzleplay'){const pm={ArrowLeft:[-1,0],a:[-1,0],ArrowRight:[1,0],d:[1,0],ArrowUp:[0,-1],w:[0,-1],ArrowDown:[0,1],s:[0,1]};if(pm[e.key]){e.preventDefault();puzzleMove(pm[e.key][0],pm[e.key][1]);return}if(e.key==='Escape'){e.preventDefault();showPuzzleMenu();return}if(e.key==='Backspace'||e.key==='z'||e.key==='Z'){e.preventDefault();puzzleUndo();return}if(e.key==='h'||e.key==='H'){e.preventDefault();puzzleHintNow();return}if(e.key==='r'||e.key==='R'){e.preventDefault();parsePuzzleLevel(puzzleLevel);return}}const k=K[e.key];
if(k){keys[k]=1;e.preventDefault()}
else if(e.key=='ArrowUp'||e.key=='w'||e.key==' '){if(!e.repeat)jumpQ=.3;e.preventDefault()}
else if(e.key=='p'||e.key=='Escape'){st=='pause'?act():pause()}
else if(e.key=='Enter'&&st!='play'){act()}});
addEventListener('keyup',e=>{const k=K[e.key];if(k)keys[k]=0});
document.querySelectorAll('[data-k]').forEach(b=>{const k=b.dataset.k;
b.addEventListener('pointerdown',e=>{e.preventDefault();b.setPointerCapture(e.pointerId);b.classList.add('on');if(k=='j')jumpQ=.3;else keys[k]=1});
const up=()=>{b.classList.remove('on');if(k!='j')keys[k]=0};
['pointerup','pointercancel','lostpointercapture'].forEach(ev=>b.addEventListener(ev,up))});
$('bp').onclick=()=>st=='pause'?act():pause();
$('bm').onclick=()=>{mute=mute?0:1;try{localStorage.setItem('sa_mute',mute)}catch(e){}hud()};
document.addEventListener('visibilitychange',()=>{if(document.hidden)pause()});addEventListener('message',e=>{if(e.data==='sa-pause'&&st==='play')pause();if(e.data==='sa-menu'){if(tut){tut=null;clearInterval(tutTimer)}coachHide();showModernSubmenu()}});
addEventListener('contextmenu',e=>e.preventDefault());

let cs=1;try{cs=+localStorage.getItem('sa_cs')||1}catch(e){}document.documentElement.style.setProperty('--cs',cs);
const ppn=document.createElement('div');ppn.id='pausePanel';ppn.innerHTML='<div class="pp-box"><h3>PAUSA</h3><button id="ppGo">▶ CONTINUAR</button><button id="ppSnd" class="alt"></button><div class="pp-row"><span>CONTROLES</span><button data-cs=".8" class="alt">P</button><button data-cs="1" class="alt">M</button><button data-cs="1.2" class="alt">G</button></div><button id="ppRst" class="alt">↻ REINICIAR</button><button id="ppLv" class="alt">☰ FASES</button><button id="ppExit" class="alt">✕ SAIR</button></div>';
document.querySelector('.screen').appendChild(ppn);
const ppShow=on=>ppn.classList.toggle('show',on),ppUnpause=()=>{if(st==='pause'){st='play';$('ov').style.display='none'}};
function ppRefresh(){$('ppSnd').textContent=mute?'🔇 SOM: DESLIGADO':'🔊 SOM: LIGADO';$('ppLv').style.display=(gameMode==='puzzle'||gameMode==='modern')?'':'none';ppn.querySelectorAll('[data-cs]').forEach(b=>b.classList.toggle('sel',+b.dataset.cs===cs))}
function ppOpen(){if(st==='play')pause();ppRefresh();ppShow(true)}
$('ppGo').onclick=()=>{ppShow(false);if(st==='pause')act()};
$('ppSnd').onclick=()=>{$('bm').click();ppRefresh()};
ppn.querySelectorAll('[data-cs]').forEach(b=>b.onclick=()=>{cs=+b.dataset.cs;document.documentElement.style.setProperty('--cs',cs);try{localStorage.setItem('sa_cs',cs)}catch(e){}ppRefresh()});
$('ppRst').onclick=()=>{ppShow(false);ppUnpause();gameMode==='puzzle'?$('pResetBtn').click():start()};
$('ppLv').onclick=()=>{ppShow(false);ppUnpause();gameMode==='puzzle'?$('pLevelsBtn').click():showCampaignMenu()};
$('ppExit').onclick=()=>{ppShow(false);ppUnpause();gameMode==='puzzle'?$('pExitBtn').click():showModeMenu()};
$('bmenu').onclick=ppOpen;$('pMenuBtn').onclick=ppOpen;
{const h=document.querySelector('.hud'),o=$('objectiveHud');let last='';const f=()=>{const s=h.textContent+o.textContent;if(s===last)return;last=s;document.body.classList.add('flash');clearTimeout(f.t);f.t=setTimeout(()=>document.body.classList.remove('flash'),1800)};const opt={subtree:true,childList:true,characterData:true};new MutationObserver(f).observe(h,opt);new MutationObserver(f).observe(o,opt)}

{let n=0,tm=0;$('ov').addEventListener('click',e=>{const h=e.target.closest&&e.target.closest('h2');if(!h||!$('campaignShopBtn')||st!=='title'||gameMode!=='modern')return;
 clearTimeout(tm);tm=setTimeout(()=>{n=0},3000);n++;
 if(n>=10){n=0;coins+=100;saveCampaign();updateCampaignHud();beep(660,.1,'triangle');setTimeout(()=>beep(880,.15,'triangle'),110);showCampaignMenu();coach('+100 moedas!',2200)}})}
hud();requestAnimationFrame(loop);

// ---- CHEAT DE TESTES: tocar 15x na palavra "MODERNO" do menu moderno ----
// libera todas as fases da campanha e as habilidades (5 de cada) e soma +200 moedas
function applyTestCheat(){
 unlockedStage=5;coins+=200;
 for(const it of shopItems)powerInventory[it.id]=Math.max(powerInventory[it.id]||0,5);
 preservePowersForNextStage=true;
 saveCampaign();updateCampaignHud();
 beep(660,.1,'triangle');setTimeout(()=>beep(880,.15,'triangle'),110);setTimeout(()=>beep(1100,.2,'triangle'),240);
 const p=$('ov').querySelector('p');if(p)p.textContent='🔓 Modo teste: todas as fases e habilidades liberadas · +200 moedas · saldo: '+coins;
}
{let n=0,tm=0;$('ov').addEventListener('click',e=>{
 const w=e.target.closest&&e.target.closest('#cheatWord');
 if(!w||st!=='title'||gameMode!=='modern')return;
 clearTimeout(tm);tm=setTimeout(()=>{n=0},2000);n++;
 if(n>=15){n=0;clearTimeout(tm);applyTestCheat()}})}
})();
