(()=>{
'use strict';
const W=12,H=7,T=window.textures,A=T.playerTexturesAnimations,L='#ff9800',D='#1a0f00';
const $=id=>document.getElementById(id),cv=$('c'),cx=cv.getContext('2d');cx.imageSmoothingEnabled=false;
const mk=()=>{const c=document.createElement('canvas');c.width=100;c.height=80;return c};
const off=mk(),ox=off.getContext('2d'),bgc=mk(),fgc=mk();
const modernCanvas=document.createElement('canvas');modernCanvas.width=800;modernCanvas.height=640;
const modernCtx=modernCanvas.getContext('2d');modernCtx.scale(8,8);modernCtx.imageSmoothingEnabled=true;modernCtx.imageSmoothingQuality='high';
function tex(g,t,x,y){for(let i=0;i<t.length;i++)for(let j=0;j<t[i].length;j++){g.fillStyle=t[i][j]===1?D:L;g.fillRect(x+j,y+i,1,1)}}
const S=16,CAR=[[1,1,1,1,1,1,1,1,1,1],[1,0,0,0,0,0,0,0,0,1],[1,1,1,0,0,0,0,1,1,1],[0,1,0,0,0,0,0,0,1,0]];
{
 const g=bgc.getContext('2d');g.fillStyle=L;g.fillRect(0,0,100,80);
 for(let i=4;i<99;i+=4)tex(g,T.floorTexture,i,60+S);
 for(let i=0;i<79;i+=4)tex(g,T.wallTexture,0,i);
 for(let i=4;i<99;i+=8)tex(g,T.backgroundTexture,i,4+S);
 for(let i=4;i<99;i+=4)tex(g,T.railingTexture,i,0);
 const f=fgc.getContext('2d');for(let i=0;i<99;i+=4)tex(f,T.railingTexture,i,S);
}
let st='title',boxes=[],P,score=0,level=1,lives=3,rows=0,spawnT=0,nextCol=0,gT=0,t=0,best=0,mute=0,jumpQ=0,iv=2.6,crane={x:6,ct:2},crushFx=null,lineFx=null;
const keys={l:false,r:false};
try{best=Number(localStorage.getItem('sa_best'))||0;mute=Number(localStorage.getItem('sa_mute'))||0}catch(e){}
let ac;
function beep(f,d=.08,ty='square'){if(mute)return;try{ac=ac||new(window.AudioContext||window.webkitAudioContext)();if(ac.state==='suspended')ac.resume();const o=ac.createOscillator(),g=ac.createGain();o.type=ty;o.frequency.value=f;g.gain.value=.05;o.connect(g);g.connect(ac.destination);o.start();o.stop(ac.currentTime+d)}catch(e){}}
const boxAt=(x,y)=>boxes.find(b=>b.x===x&&b.y===y);
const rnd=n=>Math.floor(Math.random()*n);
const ap=(a,b,m)=>a<b?Math.min(a+m,b):Math.max(a-m,b);

// Escolhe colunas com preferência por áreas baixas, especialmente os cantos.
// Quanto mais alta a pilha numa coluna, menor a chance de uma nova caixa cair ali.
function chooseSpawnColumn(){
 const heights=Array(W).fill(0);
 for(const b of boxes){
  if(b.x>=0&&b.x<W&&b.y>=0) heights[b.x]=Math.max(heights[b.x],b.y+1);
 }
 const center=(W-1)/2;
 const weights=heights.map((h,x)=>{
  const lowArea=h<=Math.floor(H/2);
  const cornerDistance=Math.min(x,W-1-x);
  const cornerBonus=1+(W/2-cornerDistance)*0.16;
  const heightPenalty=h<=H/2?1:Math.max(0.08,Math.pow(0.48,h-H/2));
  const lowBonus=lowArea?1.7:1;
  return Math.max(0.025,cornerBonus*heightPenalty*lowBonus);
 });
 const total=weights.reduce((a,b)=>a+b,0);
 let r=Math.random()*total;
 for(let x=0;x<W;x++){r-=weights[x];if(r<=0)return x}
 return rnd(W);
}
const sup=()=>P.y===0||!!boxAt(P.x,P.y-1);
function spawnP(){P.x=7;P.y=0;while(P.y<H&&boxAt(P.x,P.y))P.y++;P.y=Math.min(P.y,H-1);P.rx=P.x;P.ry=P.y;P.busy=0;P.air=0;P.anim='idle'}
P={};spawnP();let modeStr='orig';
function hud(){$('sc').textContent=score;$('lv').textContent=level;$('lf').textContent='♥'.repeat(Math.max(0,lives))||'–';$('bs').textContent=best;$('bm').style.opacity=mute?.4:1}
function overlay(h,p,buttons){const ov=$('ov');ov.classList.toggle('is-title',h==='STACK ATTACK');ov.innerHTML='<h2>'+h+'</h2><p>'+p+'</p><div style="display:flex;gap:10px;width:100%;max-width:320px;margin-top:8px;justify-content:center"></div>';const row=ov.lastElementChild;buttons.forEach(item=>{const b=document.createElement('button');b.textContent=item.label;b.onclick=item.fn;row.appendChild(b)});ov.style.display='flex'}
function hideOverlay(){$('ov').style.display='none'}
function resume(){if(st==='pause'){st='play';hideOverlay()}}
function start(m='orig'){
 modeStr=m;crushFx=null;lineFx=null;boxes=[[2,0],[4,0],[4,1],[6,0]].map(([x,y])=>({x,y,rx:x,ry:y,tx:1+rnd(6),s:1}));
 score=0;level=1;lives=3;rows=0;spawnT=-.6;gT=0;nextCol=chooseSpawnColumn();crane.x=6;crane.ct=1+rnd(6);P.x=7;spawnP();st='play';hideOverlay();hud();beep(660)
}
function pause(){if(st!=='play')return;st='pause';overlay('PAUSADO','Toque em continuar para voltar ao jogo.',[{label:'CONTINUAR',fn:resume},{label:'REINICIAR',fn:()=>start(modeStr)},{label:'MENU',fn:title}])}
function title(){st='title';overlay('STACK ATTACK','CLÁSSICO: gráficos originais do Siemens A50. MODERNO: campanha com 5 fases, objetivos claros e poderes.',[{label:'CLÁSSICO · A50',fn:()=>start('orig')},{label:'MODERNO · CAMPANHA',fn:()=>showModernGame()}])}
function over(){st='over';if(score>best){best=score;try{localStorage.setItem('sa_best',best)}catch(e){}}hud();beep(120,.5,'sawtooth');overlay('FIM DE JOGO','Pontos: '+score+' · Linhas: '+rows+' · Recorde: '+best,[{label:'JOGAR NOVAMENTE',fn:()=>start(modeStr)},{label:'MENU',fn:title}])}
function crush(){
 if(st!=='play')return;
 st='crush';
 crushFx={t:0,duration:.9,x:P.x,y:P.y,phase:0};
 jumpQ=0;keys.l=false;keys.r=false;
 beep(90,.3,'sawtooth');
 cv.classList.remove('hit');void cv.offsetWidth;cv.classList.add('hit');
}
function finishCrush(){
 lives--;hud();crushFx=null;
 if(lives<=0){over();return}
 // Remove only the lowest clutter, then respawn at the safest available corner.
 boxes=boxes.filter(b=>b.y<2);
 const candidates=[0,W-1,1,W-2,2,W-3];
 let sx=candidates.find(x=>!boxAt(x,0)&&!boxAt(x,1));
 if(sx===undefined){
  sx=Array.from({length:W},(_,i)=>i).find(x=>!boxAt(x,0)&&!boxAt(x,1));
 }
 if(sx===undefined){
  // Último recurso: abrir espaço embaixo para nunca nascer dentro de uma caixa.
  boxes=boxes.filter(b=>b.y>1);
  sx=candidates.find(x=>!boxAt(x,0)&&!boxAt(x,1));
 }
 if(sx===undefined)sx=0;
 P.x=sx;P.y=0;P.rx=sx;P.ry=0;P.busy=0;P.air=0;P.anim='idle';
 spawnT=-1;gT=0;st='play';beep(240,.12,'triangle');
}
function finishLineClear(){
 if(!lineFx)return;
 const n=lineFx.rows.length;
 boxes=boxes.filter(b=>!lineFx.rows.includes(b.y));
 score+=100*level*n*n;rows+=n;
 const nl=1+Math.floor(rows/4);
 if(nl>level)beep(880,.2);
 level=nl;beep(520,.15);beep(780,.2,'triangle');
 lineFx=null;hud();
}
function gravity(){
 boxes.sort((a,b)=>a.y-b.y);
 for(const b of boxes){
  if(b.y===0||boxAt(b.x,b.y-1))continue;
  const ny=b.y-1;
  // A caixa não pode atravessar o personagem: verifica a célula ocupada
  // e o espaço imediatamente acima do personagem antes de descer.
  if(P.x===b.x&&(ny===P.y||ny===P.y+1||b.y===P.y+2)){crush();return}
  b.y=ny;
 }
 boxes.sort((a,b)=>a.y-b.y);
 for(const b of boxes){const below=b.y>0?boxAt(b.x,b.y-1):null;b.s=(b.y===0||(below&&below.s))?1:0}
 if(boxes.some(b=>b.s&&b.y>=H)){over();return}
 const full=[];for(let y=0;y<H;y++){const row=boxes.filter(b=>b.y===y&&b.s);if(row.length===W&&new Set(row.map(b=>b.x)).size===W)full.push(y)}
 if(full.length){
  lineFx={rows:full,t:0,duration:.58,particles:Array.from({length:48},()=>({x:Math.random()*W,y:full[rnd(full.length)],vx:(Math.random()-.5)*10,vy:(Math.random()-.5)*8,size:.08+Math.random()*.14,color:Math.random()>.45?'#fff176':'#fff'}))};
  beep(620,.12,'triangle');
 }
}
function tryMove(d){
 const nx=P.x+d;if(nx<0||nx>=W)return false;
 const s=sup();
 if(!boxAt(nx,P.y)&&!boxAt(nx,P.y+1)&&(s||boxAt(nx,P.y-1))){P.x=nx;P.busy=.14;P.anim=d<0?'wl':'wr';return true}
 const bx=boxAt(nx,P.y),n2=nx+d;
 // Também é possível empurrar uma caixa lateralmente durante o salto.
 // A caixa só se move se o espaço à frente estiver livre.
 if(bx&&n2>=0&&n2<W&&!boxAt(n2,P.y)&&
    (P.air>0||P.y>0||bx.s)&&
    (!boxAt(nx,P.y+1)||P.y>0)){
  const oldBoxX=bx.x;
  bx.x=n2;bx.rx=oldBoxX;bx.s=0;
  P.x=nx;P.rx=nx;
  P.busy=.18;P.anim=d<0?'pl':'pr';
  beep(220,.07,'square');
  return true;
 }
 return false
}
function step(dt){
 if(st==='crush'){
  if(crushFx){crushFx.t+=dt;if(crushFx.t>=crushFx.duration)finishCrush()}
  return;
 }
 if(st!=='play')return;
 if(lineFx){
  lineFx.t+=dt;
  if(lineFx.t>=lineFx.duration)finishLineClear();
  else{
   for(const p of lineFx.particles){p.x+=p.vx*dt;p.y+=p.vy*dt;}
   return;
  }
 }
 iv=Math.max(.9,2.6-.2*(level-1));const G=Math.max(.1,.2-.012*(level-1));
 spawnT+=dt;crane.x=ap(crane.x,nextCol,dt*9);
 if(spawnT>=iv){if(Math.abs(crane.x-nextCol)<.05){if(!boxAt(nextCol,H))boxes.push({x:nextCol,y:H,rx:nextCol,ry:8,tx:1+rnd(6),s:0});nextCol=chooseSpawnColumn();crane.ct=1+rnd(6);spawnT=0;beep(300,.05)}else spawnT=iv}
 gT+=dt;while(gT>=G&&st==='play'){gT-=G;gravity()}
 if(st!=='play')return;
 jumpQ=Math.max(0,jumpQ-dt);if(P.busy>0)P.busy-=dt;
 if(P.busy<=0){
  const s=sup(),dir=(keys.r?1:0)-(keys.l?1:0);if(s)P.air=0;
  if(jumpQ>0&&s&&P.y+1<H&&!boxAt(P.x,P.y+1)){
   jumpQ=0;P.y++;P.busy=.16;P.air=.01;P.anim='jump';beep(440,.07);
  }else if(dir&&tryMove(dir)){}
  else if(!s){P.air+=dt;P.anim='jump';if(P.air>=.12){P.y=Math.max(0,P.y-1);P.busy=.07;P.air=0}}
  else P.anim='idle'
 }
 for(const b of boxes){b.ry=ap(b.ry,b.y,dt*12);b.rx=ap(b.rx,b.x,dt*8)}
 P.rx=ap(P.rx,P.x,dt*10);P.ry=ap(P.ry,P.y,dt*10)
}
function frame(){const m={wl:'walkLeft',wr:'walkRight',pl:'pushLeft',pr:'pushRight',idle:'idle'};if(P.anim==='jump')return A.jump[0];const a=A[m[P.anim]]||A.idle;return a[Math.floor(t*(P.anim==='idle'?2:6))%a.length]}

const modernAssets={worker:new Image(),crate:new Image(),city:new Image(),impact:new Image()};
modernAssets.worker.src='img/worker.png';
modernAssets.crate.src='img/crate.png';
modernAssets.city.src='img/city.png';
modernAssets.impact.src='';
function loadModernFrames(urls){return urls.map(src=>{const im=new Image();im.src=src;return im;});}
const modernFrames={
 idle:loadModernFrames(['img/idle_0.png','img/idle_1.png','img/idle_2.png','img/idle_3.png']),
 run:loadModernFrames(['img/run_0.png','img/run_1.png','img/run_2.png','img/run_3.png','img/run_4.png','img/run_5.png','img/run_6.png','img/run_7.png']),
 jump:loadModernFrames(['img/jump_0.png','img/jump_1.png','img/jump_2.png','img/jump_3.png','img/jump_4.png','img/jump_5.png']),
 push:loadModernFrames(['img/push_0.png','img/push_1.png','img/push_2.png','img/push_3.png','img/push_4.png']),
 crush:loadModernFrames(['img/crush_0.png','img/crush_1.png','img/crush_2.png','img/crush_3.png','img/crush_4.png','img/crush_5.png'])
};
let modernFrameIndex=0,modernFrameTick=0;
function currentModernSprite(){
 let seq=modernFrames.idle, rate=4;
 if(crushFx){seq=modernFrames.crush;rate=8;}
 else if(P.jumping||P.vy<0){seq=modernFrames.jump;rate=8;}
 else if(P.pushing){seq=modernFrames.push;rate=7;}
 else if(Math.abs(P.vx||0)>.05){seq=modernFrames.run;rate=10;}
 const now=performance.now();
 if(now-modernFrameTick>1000/rate){modernFrameIndex=(modernFrameIndex+1)%seq.length;modernFrameTick=now;}
 return seq[modernFrameIndex%seq.length];
}
function roundRect(g,x,y,w,h,r,fill,stroke){
 g.beginPath();g.moveTo(x+r,y);g.arcTo(x+w,y,x+w,y+h,r);g.arcTo(x+w,y+h,x,y+h,r);g.arcTo(x,y+h,x,y,r);g.arcTo(x,y,x+w,y,r);
 if(fill){g.fillStyle=fill;g.fill()}if(stroke){g.strokeStyle=stroke;g.lineWidth=.7;g.stroke()}
}
function modernBackground(g){
 const sky=g.createLinearGradient(0,0,0,80);sky.addColorStop(0,'#101c3c');sky.addColorStop(.55,'#542b63');sky.addColorStop(1,'#ff8a42');
 g.fillStyle=sky;g.fillRect(0,0,100,80);
 // Distant skyline and glowing windows
 for(let i=0;i<15;i++){const x=i*7-2,h=10+(i*13%19);g.fillStyle=i%2?'#1b2446':'#25264d';g.fillRect(x,49-h,5,h+2);
  for(let wy=51-h;wy<49;wy+=4){g.fillStyle=(i+wy)%3?'#ffb45b':'#8edcff';g.fillRect(x+1,wy,1,1)}
 }
 const glow=g.createRadialGradient(72,43,1,72,43,32);glow.addColorStop(0,'rgba(255,177,82,.25)');glow.addColorStop(1,'rgba(255,177,82,0)');g.fillStyle=glow;g.fillRect(35,10,65,55);
 g.fillStyle='#171b32';g.fillRect(0,60,100,20);
 const floorGlow=g.createLinearGradient(0,60,0,80);floorGlow.addColorStop(0,'#39415f');floorGlow.addColorStop(.16,'#252c49');floorGlow.addColorStop(1,'#111629');
 g.fillStyle=floorGlow;g.fillRect(0,60,100,20);
 for(let x=0;x<100;x+=4){g.fillStyle='#59617b';g.fillRect(x,60,3,.7)}
 g.fillStyle='rgba(255,145,65,.08)';g.fillRect(0,61,100,1)
}
function modernCrate(g,x,y,tx){
 const px=x,py=y;
 g.save();g.shadowColor='rgba(0,0,0,.35)';g.shadowBlur=2;g.shadowOffsetY=1;
 const grad=g.createLinearGradient(px,py,px+8,py+8);grad.addColorStop(0,tx%2?'#ffb24a':'#657da5');grad.addColorStop(.5,tx%2?'#d76527':'#344c73');grad.addColorStop(1,tx%2?'#80351e':'#1b2b48');
 roundRect(g,px+.25,py+.25,7.5,7.5,.8,grad,'#15192c');g.restore();
 g.strokeStyle=tx%2?'#ffcb7a':'#9bb4d9';g.lineWidth=.45;g.strokeRect(px+1,py+1,6,6);
 g.strokeStyle=tx%2?'#9c421e':'#263955';g.beginPath();g.moveTo(px+1.5,py+1.5);g.lineTo(px+6.5,py+6.5);g.moveTo(px+6.5,py+1.5);g.lineTo(px+1.5,py+6.5);g.stroke();
 g.fillStyle='#ffe1a1';g.fillRect(px+1,py+1,1,1);g.fillRect(px+6,py+6,1,1);
}
function modernCharacter(g,x,y){
 g.save();g.shadowColor='rgba(0,0,0,.4)';g.shadowBlur=2;
 // boots, body, head and orange hard hat
 roundRect(g,x+1,y+12,3,3,1,'#172039');roundRect(g,x+5,y+12,3,3,1,'#172039');
 roundRect(g,x+1,y+6,7,7,1,'#ff762b','#702b22');
 roundRect(g,x+2,y+1,6,6,2,'#ffc28a','#713e35');
 g.fillStyle='#22223a';g.fillRect(x+3,y+3,1,1);g.fillRect(x+6,y+3,1,1);
 roundRect(g,x+1,y,7,2,1,'#ff9d32','#7e3a1b');g.fillStyle='#ffe2a1';g.fillRect(x+3,y,2,1);
 g.restore();
}
function drawModern(){
 const g=modernCtx;g.clearRect(0,0,100,80);
 modernBackground(g);
 if(modernAssets.city.complete&&modernAssets.city.naturalWidth){
  g.save();g.globalAlpha=.96;g.drawImage(modernAssets.city,0,8,100,37);g.restore();
 }
 g.save();g.translate(0,S);
 for(const b of boxes){if(b.y>=0&&b.y<H){const x=Math.round(b.rx*8+4),y=Math.round(64-(b.ry*8+4)-8);
  if(lineFx&&lineFx.rows.includes(b.y)){g.fillStyle=`rgba(255,240,155,${.3+.5*(.5+.5*Math.sin(lineFx.t*42))})`;g.fillRect(x,y,8,8)}
  else if(modernAssets.crate.complete&&modernAssets.crate.naturalWidth)g.drawImage(modernAssets.crate,x,y,8,8);
  else modernCrate(ox,x,y,b.tx);
 }}
 if(crushFx){const q=Math.min(1,crushFx.t/crushFx.duration),x=crushFx.x*8+4,y=64-(crushFx.y*8+4)-12;g.fillStyle='#fff';g.globalAlpha=.8;g.fillRect(x-2,y+9,12,2);g.globalAlpha=1;roundRect(ox,x,y+q*5,8,Math.max(2,8-q*5),1,'#ff6d32','#66251c')}
 else if(P.y>=0&&P.y<H){
  const px=Math.round(P.rx*8+1),py=Math.round(64-(P.ry*8+4)-16);
  const sprite=currentModernSprite();
  if(sprite&&sprite.complete&&sprite.naturalWidth){
   g.imageSmoothingEnabled=true;g.imageSmoothingQuality='high';
   g.drawImage(sprite,px-2,py-3,18,21);
  } else if(modernAssets.worker.complete&&modernAssets.worker.naturalWidth){
   g.drawImage(modernAssets.worker,px-1,py-1,16,18);
  } else modernCharacter(ox,px,py);
 }
 if(lineFx){for(const p of lineFx.particles){g.fillStyle=p.color;g.fillRect(p.x*8+4,64-(p.y*8+4)-8,Math.max(.5,p.size*8),Math.max(.5,p.size*8))}g.fillStyle='#fff4be';g.font='bold 5px sans-serif';g.textAlign='center';g.fillText('LINHA COMPLETA!',50,34)}
 g.restore();
 // Modern overhead rail, moving trolley, claw and suspended crate
 const gx=Math.max(5,Math.min(87,Math.round(crane.x*8+1)));
 const rail=g.createLinearGradient(0,0,0,4);rail.addColorStop(0,'#dcecff');rail.addColorStop(.5,'#5b769e');rail.addColorStop(1,'#172642');
 g.fillStyle=rail;g.fillRect(0,0,100,4);roundRect(ox,gx,0,8,5,1,'#ff9b39','#2a2440');
 g.fillStyle='#e8f5ff';g.fillRect(gx+2,1,1,1);g.fillRect(gx+5,1,1,1);
 g.fillStyle='#202844';g.fillRect(gx+3,5,2,6);g.fillRect(gx,11,2,3);g.fillRect(gx+6,11,2,3);
 if(modernAssets.crate.complete&&modernAssets.crate.naturalWidth)g.drawImage(modernAssets.crate,gx,17,8,8);
 else modernCrate(ox,gx,17,crane.ct);
 cx.drawImage(modernCanvas,0,0,cv.width,cv.height);
}
function draw(){
 if(modeStr==='modern'){drawModern();return}
 ox.clearRect(0,0,100,80);ox.drawImage(bgc,0,0);ox.save();ox.translate(0,S);
 for(const b of boxes){
  if(b.y>=0&&b.y<H){
   const clearing=lineFx&&lineFx.rows.includes(b.y);
   if(clearing){
    const pulse=.5+.5*Math.sin(lineFx.t*42);
    ox.fillStyle=`rgba(255,255,190,${.35+.55*pulse})`;
    ox.fillRect(Math.round(b.rx*8+4),Math.round(64-(b.ry*8+4)-8),8,8);
    if(pulse>.45)tex(ox,T.boxTextures[b.tx]||T.boxTextures[1],Math.round(b.rx*8+4),Math.round(64-(b.ry*8+4)-8));
   }else tex(ox,T.boxTextures[b.tx]||T.boxTextures[1],Math.round(b.rx*8+4),Math.round(64-(b.ry*8+4)-8));
  }
 }
 if(crushFx){
  const q=Math.min(1,crushFx.t/crushFx.duration),px=Math.round(crushFx.x*8+4),py=Math.round(64-(crushFx.y*8+4)-16);
  // Corpo achatando, faíscas e poeira: a animação fica visível antes da perda de vida.
  ox.fillStyle='#fff3c4';ox.fillRect(px-2,py+10,12,3);
  ox.fillStyle='#e65100';ox.fillRect(px,py+Math.round(4+q*8),8,Math.max(2,8-Math.round(q*6)));
  ox.fillStyle=D;ox.fillRect(px+1,py+Math.round(5+q*8),2,2);ox.fillRect(px+5,py+Math.round(5+q*8),2,2);
  for(let i=0;i<7;i++){
   const a=i*2.399,dist=2+q*10;
   ox.fillStyle=i%2?'#fff176':'#fff';
   ox.fillRect(Math.round(px+4+Math.cos(a)*dist),Math.round(py+8+Math.sin(a)*dist),1,1);
  }
  if(q>.35){ox.fillStyle=D;ox.font='bold 5px monospace';ox.textAlign='center';ox.fillText('ESMAGADO!',px+4,py-2)}
 }else if(P.y>=0&&P.y<H){
  tex(ox,frame(),Math.round(P.rx*8+4),Math.round(64-(P.ry*8+4)-16));
 }
 if(lineFx){
  for(const p of lineFx.particles){
   const px=Math.round(p.x*8+4),py=Math.round(64-(p.y*8+4)-8);
   ox.fillStyle=p.color;
   ox.fillRect(px,py,Math.max(1,Math.round(p.size*8)),Math.max(1,Math.round(p.size*8)));
  }
  ox.fillStyle='#fff8c4';ox.font='bold 7px monospace';ox.textAlign='center';ox.fillText('LINHA COMPLETA!',50,34);
 }
 if(st==='play'&&spawnT>iv-1.2&&Math.floor(t*8)%2){const c=nextCol*8+8;ox.fillStyle=D;ox.fillRect(c-3,4,6,1);ox.fillRect(c-2,5,4,1);ox.fillRect(c-1,6,2,1)}
 ox.restore();ox.drawImage(fgc,0,0);tex(ox,CAR,Math.round(crane.x*8+3),0);tex(ox,T.boxTextures[crane.ct]||T.boxTextures[1],Math.round(crane.x*8+4),4);cx.drawImage(off,0,0,cv.width,cv.height)
}
let last=0;function loop(ts){if(document.body.dataset.st!==st)document.body.dataset.st=st;const dt=Math.min(.05,(ts-last)/1000||0);last=ts;t+=dt;if(st==='play'||st==='crush')step(dt);draw();requestAnimationFrame(loop)}
const K={ArrowLeft:'l',a:'l',A:'l',ArrowRight:'r',d:'r',D:'r'};
addEventListener('keydown',e=>{const k=K[e.key];if(k){keys[k]=true;e.preventDefault()}else if(e.key==='ArrowUp'||e.key==='w'||e.key==='W'||e.key===' '){if(!e.repeat)jumpQ=.3;e.preventDefault()}else if(e.key==='p'||e.key==='P'||e.key==='Escape'){st==='pause'?resume():pause()}else if(e.key==='Enter'&&st!=='play'){if(st==='pause')resume();else title()}});
addEventListener('keyup',e=>{const k=K[e.key];if(k)keys[k]=false});
document.querySelectorAll('[data-k]').forEach(b=>{const k=b.dataset.k;b.addEventListener('pointerdown',e=>{e.preventDefault();try{b.setPointerCapture(e.pointerId)}catch(_){}b.classList.add('on');if(k==='j')jumpQ=.3;else keys[k]=true});const up=()=>{b.classList.remove('on');if(k!=='j')keys[k]=false};['pointerup','pointercancel','lostpointercapture'].forEach(ev=>b.addEventListener(ev,up))});
$('bp').onclick=()=>st==='pause'?resume():pause();
$('bm').onclick=()=>{mute=mute?0:1;try{localStorage.setItem('sa_mute',mute)}catch(e){}hud()};
document.addEventListener('visibilitychange',()=>{if(document.hidden)pause()});
addEventListener('contextmenu',e=>e.preventDefault());
hud();title();requestAnimationFrame(loop);try{if(!localStorage.getItem('sa_seen')){localStorage.setItem('sa_seen','1');addEventListener('load',()=>{if(typeof showModernGame==='function')showModernGame()})}}catch(e){};
})();
