// Carrega o modo MODERNO (modern/index.html) só quando o jogador abre.
(()=>{
 const host=document.getElementById('modern-host');
 const frame=document.getElementById('modern-frame');
 window.showModernGame=function(){
   host.style.display='flex';
   if(!frame.dataset.loaded){frame.src='modern/index.html';frame.dataset.loaded='1';}
   else{try{frame.contentWindow.postMessage('sa-menu','*')}catch(e){}}
 };
})();
