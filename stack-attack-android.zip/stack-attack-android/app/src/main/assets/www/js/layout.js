(()=>{const mq=matchMedia("(orientation:landscape) and (min-width:560px)"),hud=document.querySelector(".hud"),app=document.querySelector(".app");if(!hud||!app)return;const side=document.createElement("div");side.id="sideR";hud.after(side);
const mv=()=>["bp","bm","bmenu","shopBtn"].forEach(n=>{const e=document.getElementById(n);if(e)(mq.matches?side:hud).appendChild(e)});
mq.addEventListener?mq.addEventListener("change",mv):mq.addListener(mv);mv()})()
